# CPENT-project Security Threat Model

## Overview

`CPENT-project` is a static Markdown knowledge base for beginner-friendly preparation for the EC-Council Certified Penetration Testing Professional (CPENT) curriculum. It contains study plans, module notes, lab and reporting templates, commands, quizzes, flashcards, and links to external learning resources. It does not contain an application runtime, package dependencies, a build pipeline, or deployed authentication and authorization logic.

The most important assets are the learner's safety and authorization boundaries, the integrity and accuracy of study instructions, any evidence copied into the repository, the confidentiality of credentials or real target details, and the trustworthiness of external resources. Security review therefore centers on repository content and the way a learner may copy it into a terminal or penetration-testing workflow.

## Threat Model, Trust Boundaries, and Assumptions

- **Repository contributors to Git history:** Maintainers and contributors can introduce Markdown, shell commands, URLs, templates, or lab evidence. A malicious or mistaken contribution could persist in clones and be followed by learners.
- **Study content to learner execution:** Text becomes security-sensitive when a learner copies a command, request, payload, or target into a privileged shell or an offensive-security tool. The repository must keep authorization, scope, non-destructive limits, evidence handling, and cleanup explicit.
- **Learner evidence to public repository:** Lab notes, screenshots transcribed into Markdown, packet-capture details, tokens, credentials, private IPs, customer identifiers, or client targets may cross from an approved environment into public Git history.
- **Repository to external resources:** Links to course providers, labs, binaries, tools, and documentation cross into third-party trust domains. A compromised or changed link could provide misleading instructions, credential phishing, or malicious downloads.
- **Templates to completed reports:** Placeholders are safe only while they remain obvious placeholders. Real client or production data inserted into reusable templates must not be committed.

Attacker-controlled inputs include malicious pull-request content, compromised linked pages, and untrusted lab output pasted by a learner. Operator-controlled inputs include target scope, rules of engagement, lab addresses, credentials, evidence, and tool options selected during authorized testing. Developer-controlled inputs include repository policies, examples, templates, and review decisions.

Assumptions:

- Learners use the material only in isolated labs or on systems covered by explicit authorization.
- GitHub renders Markdown without executing fenced code automatically; exploitation generally requires a learner to click a link, download an artifact, or copy and run a command.
- Repository history is public or broadly shareable, so deletion from the latest tree alone cannot reliably revoke an exposed secret.
- The repository's `AGENTS.md`, `SECURITY.md`, `CONTRIBUTING.md`, and root `README.md` are intended controls and apply repository-wide.

Security invariants:

- No real credentials, access tokens, private keys, customer data, proprietary course material, private targets, or unredacted sensitive evidence may be committed.
- Commands and offensive techniques must use unmistakable lab placeholders or synthetic targets and be framed by authorization and scope.
- Content must not direct learners to destructive, denial-of-service, persistence, or evasion actions outside a clearly controlled lab.
- External resources must not be represented as trusted executables without provenance and verification guidance.
- Reports must distinguish observation from supported impact, preserve timestamps and traceability, and redact sensitive material.

## Attack Surface, Mitigations, and Attacker Stories

Primary attack surfaces are Markdown commands and code blocks, raw URLs, module lab instructions, evidence and reporting templates, and future contributed artifacts. The current tree contains only regular Markdown/configuration text files, with no symlinks, executables, archives, packet captures, or runtime code.

Existing mitigations are strong and consistent at the policy layer: `SECURITY.md` limits use to authorized targets and requires redaction; `AGENTS.md` requires synthetic examples, safety-first lab structure, cleanup, and non-destructive defaults; `CONTRIBUTING.md` bans credentials, tokens, personal data, packet captures, and proprietary course material; the root `README.md` repeats authorization boundaries and recommends intentionally vulnerable practice platforms.

Realistic attacker or failure stories include:

- A contributor commits a live API token, password, private target, or client evidence that becomes recoverable from Git history.
- A command example contains a real public hostname/IP or omits a required lab-only boundary, causing an inexperienced learner to test an unauthorized system.
- A contribution embeds a shell one-liner or download command that executes untrusted remote content when copied.
- A legitimate external training link is replaced or compromised and leads a learner to malware or credential theft.
- A report template is completed with unredacted client data and committed publicly.
- Inaccurate safety or methodology guidance causes unsupported impact claims, evidence loss, or failure to clean up an authorized lab.

Less relevant vulnerability classes are conventional web flaws such as SQL injection, cross-site scripting, server-side request forgery, cross-site request forgery, session fixation, or tenant authorization bypass: the repository has no web application runtime or server-side request processing. Markdown-renderer vulnerabilities in GitHub or a local editor are generally outside this repository's control unless the repository deliberately contains a known exploit artifact.

## Severity Calibration (Critical, High, Medium, Low)

- **Critical:** A committed credential or private key directly enables compromise of a production, client, or privileged security-testing system; or a default study command reliably executes attacker-controlled code with the learner's privileges and is presented as a required step.
- **High:** Public disclosure of sensitive client evidence or a private target with actionable access details; a clearly reachable malicious command/download path likely to compromise a learner; or unsafe instructions that reliably cause destructive activity against a non-lab system.
- **Medium:** A real but lower-privilege secret; a concrete public target embedded in copy-ready instructions; an external download lacking integrity controls where exploitation still needs meaningful user action; or a safety omission likely to cause unauthorized scanning without immediate compromise.
- **Low:** Broken or misleading links, ambiguous placeholders, weak redaction examples, minor unsafe wording, unsupported severity language, or missing cleanup/evidence guidance with limited direct security impact.

Repository: target_sha256_b3a96fac48e989021dadf0414991c8c682fdb60588d06a46d677c794da58aaa2
Version: 0229ad894c204d3b541825d46d8f95f86f59e3a5
