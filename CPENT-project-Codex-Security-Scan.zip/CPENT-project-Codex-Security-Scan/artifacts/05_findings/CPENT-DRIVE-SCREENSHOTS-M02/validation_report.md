# Validation Report: CPENT-DRIVE-SCREENSHOTS-M02

## Candidate

- Candidate ID: `CPENT-DRIVE-SCREENSHOTS-M02`
- Instance: `external-sensitive-resource-link:Notes/CPENT_Modules_01_02.md:428`
- Ledger row: `FAMILY-LINKS`
- Root control: `Notes/CPENT_Modules_01_02.md:428`
- Confidence: High
- Method: static source/control/sink trace plus anonymous browser reproduction

## Validation rubric

- [x] The repository describes the linked source as 105 Module 02 screenshots covering CPENT pages 79-190.
- [x] The exact folder locator is committed in public Markdown.
- [x] The folder renders to a signed-out visitor without an access request.
- [x] The public listing exposes shared PNG filenames and sizes consistent with the described screenshot set.
- [x] No repository control prevents public link-holder access; the effective Drive ACL is permissive.

## Evidence and test notes

`Notes/CPENT_Modules_01_02.md:12` describes 105 screenshots covering pages 79-190, and line 428 publishes the Drive URL. A clean cloud browser opened that exact URL without authentication. The page title was `Scopes and engagement - Google Drive`; a separate `Iniciar sesión` link was present while a folder grid rendered shared image entries such as `IMG_0013.PNG`, `IMG_0015.PNG`, and subsequent PNG files with sizes. The signed-out toolbar also exposed `Descargar todo` (Download all). No download was initiated and no file body was opened.

The earlier public-web opener did not reach Drive and produced a deferred result. The direct signed-out browser reproduction supersedes that environmental proof gap.

## Counterevidence and uncertainty

No credential or private target is directly present in the Markdown. The impact is unauthorized bulk disclosure of course/source material, not direct system compromise. Image bodies were not inspected, but the repository's exact source description, the folder title, the publicly listed PNG collection, and the anonymous bulk-download control provide strong exposure evidence.

## Minimal remediation validation

Remove the folder URL from public Markdown and change Drive sharing to restricted. Recheck the same URL in a signed-out browser and require an access-denied or sign-in-only response.

## Closure

| Ledger row id | Instance key | Source anchor | Root control | Entrypoint/source | Sink/control | Disposition | Counterevidence or proof gap | Survives |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `FAMILY-LINKS` | `external-sensitive-resource-link:Notes/CPENT_Modules_01_02.md:428` | `Notes/CPENT_Modules_01_02.md:12` | `Notes/CPENT_Modules_01_02.md:428` | Public repository reader | Anonymous Drive folder listing | `reportable` | Image bodies were not opened; repository evidence establishes the collection's CPENT page-screenshot purpose | `yes` |
