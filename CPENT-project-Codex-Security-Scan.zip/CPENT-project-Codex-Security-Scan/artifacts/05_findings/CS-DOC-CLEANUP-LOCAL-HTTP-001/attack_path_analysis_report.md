# Attack-Path Analysis: CS-DOC-CLEANUP-LOCAL-HTTP-001

## Finding identity

- **Title:** Completed lab report leaves a temporary localhost HTTP server running without a verified cleanup step
- **Candidate ID:** `CS-DOC-CLEANUP-LOCAL-HTTP-001`
- **Ledger row:** `FAMILY-CMD`
- **Instance:** `incomplete-cleanup:Module-01-Principles/Mini-Report.md:184`
- **Validation result:** The documentation-level cleanup omission is validated.
- **Final policy decision:** `ignore`
- **Final severity:** None; the severity-policy matrix suppresses the path.

## Preserved affected locations

| Label | Location | Evidence |
|---|---|---|
| `entrypoint/sink` | `Module-01-Principles/Mini-Report.md:100-105` | Starts Python's HTTP server on `127.0.0.1:8000` and verifies it locally. |
| `reachability` | `Module-01-Principles/Mini-Report.md:169-177` | Records that the original process remains active when a second start attempt fails. |
| `root_control` | `Module-01-Principles/Mini-Report.md:179-185` | Cleanup says the service “can be stopped” but records neither termination nor verification. |

## Factual numbered attack path

1. A learner on a self-owned Kali Linux lab host runs `python3 -m http.server 8000 --bind 127.0.0.1` from an unspecified current working directory (`Module-01-Principles/Mini-Report.md:6-9,100-105`).
2. Python binds the service to IPv4 loopback and serves the current directory with the learner process's file-read privileges. The command is foreground-oriented and continues serving until interrupted or terminated.
3. The report confirms the original server remains active after a duplicate start attempt (`Module-01-Principles/Mini-Report.md:169-177`). Its completed cleanup section does not state that the process was stopped or verify that port 8000 closed (`Module-01-Principles/Mini-Report.md:179-185`).
4. To use this state, an attacker would need an already-running process or lower-privileged login on the same lab host, know or discover loopback port 8000, and issue HTTP requests before the learner closes or interrupts the server.
5. Only if the unspecified working directory contains files readable by the learner but otherwise unavailable to that local actor could the listener cross an OS-user boundary and disclose them. The repository proves neither a hostile local actor nor sensitive served files, so the demonstrated outcome is only a self-owned host retaining an unnecessary temporary listener.

## Attack Path Facts

- **Assumptions:** The documented Python semantics apply; the server remains active for some period after the recorded checks; no unrecorded teardown is credited. A sensitive directory and hostile local principal are not assumed because repository evidence does not establish them.
- **Context:** The observed state is self-only on a learner-owned local lab. The report identifies the environment as a local Kali lab and the target as `127.0.0.1:8000` only (`Module-01-Principles/Mini-Report.md:6-9,17`). No meaningful boundary crossing is verified.
- **In-Scope Status According to the Threat Model:** The documentation command and missing cleanup are in scope because the threat model explicitly treats copy-ready commands, learner execution, and failure to clean up an authorized lab as content-security surfaces. The resulting listener is not a repository product service or production workflow; the repository is static Markdown with no deployed runtime.
- **Exposure:** Not public and not local-network reachable. The command explicitly binds IPv4 loopback at `127.0.0.1:8000`, and the report states only the local machine was tested (`Module-01-Principles/Mini-Report.md:17,49,102,111`).
- **Identity:** The server runs as the learner's interactive local user. No service account, managed identity, elevated privilege, or separate victim identity is present.
- **Cross-Boundary Behavior:** Unverified. A lower-privileged local user could theoretically receive files through the learner-owned server, but the repository establishes neither a multi-user host nor any file that creates a privilege or confidentiality delta.
- **Vector:** `localhost`. Both server and client verification use `127.0.0.1`; no wildcard, LAN, or public bind is documented.
- **Preconditions:** The service must still be running; the attacker must already have code execution or a login on the same learner host; the working directory must contain material worth reading; and that material must be inaccessible to the attacker except through the server. Same-host access is technically possible, but the lower-privileged hostile actor and sensitive directory preconditions are unsupported in this self-owned lab.
- **Attacker Input Control:** Plausible only for HTTP request paths after the attacker has same-host access. No remote attacker input reaches the listener.
- **Category:** Incomplete cleanup / residual temporary service (`CWE-459`).
- **Mitigations Already Present:** Explicit `127.0.0.1` binding; self-owned authorized lab; no public or third-party targets; foreground process lifetime; advice to stop temporary services; warning not to serve sensitive directories; sanitized public evidence (`Module-01-Principles/Mini-Report.md:17,47-57,127,161-163`).
- **Auth Scope:** Internal-only in the strongest sense: unauthenticated HTTP on localhost, reachable only after access to the learner's host. No repository evidence shows a realistic lower-privileged in-scope attacker.
- **Impact Surface:** Local runtime/file exposure only. No production data, credential, client evidence, service availability, identity, or network control impact is demonstrated.
- **Target Reach:** Single temporary process on one self-owned learner host.
- **Secrets References:** None. The report states evidence was sanitized and private evidence stayed in a private workspace; no served secret or sensitive filename is identified.
- **Counterevidence:** The target is explicitly loopback-only and self-owned, public and third-party systems are excluded, the server is foreground-oriented, safe-directory and stop-service guidance exists, and no sensitive served file or hostile same-host principal is shown. This evidence is dispositive for reportability because it reduces the proven path to self-only cleanup hygiene rather than an attacker-reachable security boundary failure.
- **Blindspots:** The working directory, its contents, host user model, exact server lifetime after the report, and any unrecorded manual teardown are unknown. These unknowns cannot be filled with adverse assumptions for final policy.
- **Controls:** Network binding is correctly constrained; the missing control is only explicit termination plus verification. Adding a recorded interrupt/PID termination and a negative `ss` or HTTP check would close the documentation gap.
- **Confidence:** High in the localhost-only incomplete-cleanup fact; high in the `ignore` policy decision under the supplied matrix; low confidence that any attacker-impacting disclosure occurred.

## Counterevidence challenges

| Field challenged | Strongest counterevidence | Result |
|---|---|---|
| Scope | The threat model includes documentation cleanup, but the repository has no application runtime and this service exists only in a learner exercise. | Content issue is in scope; production/product exploitation is not. |
| Vector | Explicit `--bind 127.0.0.1` and repeated localhost-only statements. | `localhost`, not remote or local network. |
| Auth scope | HTTP itself has no authentication, but a requester first needs access to the same self-owned lab host. | Internal/localhost-only; no realistic in-scope lower-privileged actor shown. |
| Exposure | No wildcard listener, ingress, load balancer, public address, or other-host client exists. | Public exposure is disproven by repository evidence. |
| Cross-boundary behavior | No second OS identity, sensitive file, or permission delta is documented. | Boundary crossing is speculative and not established. |
| Preconditions | Sensitive current-directory contents and a hostile same-host principal are both required for confidentiality impact. | Technically possible but unsupported and contrived in the documented single-user lab. |
| Impact | The report labels the service informational, sanitizes evidence, and warns against sensitive directories; no actual file disclosure is shown. | Proven impact is an unnecessary temporary local listener only. |

## Impact calibration

**Impact: `low`.** The validated defect is incomplete documented cleanup. The strongest supported consequence is a temporary loopback listener on a self-owned training machine. File disclosure requires additional unproven facts: sensitive files in the working directory and a different, lower-privileged local actor. No secret, client data, private target, production asset, or destructive action is involved.

## Likelihood calibration

**Likelihood: `low`.** The established vector is `localhost`. An attacker must already have execution or a login on the same lab host and reach the service before it stops. The repository supplies no realistic lower-privileged local attacker, multi-user deployment, or durable persistence mechanism. Remote and LAN attackers cannot reach the explicit loopback bind.

## Mechanical severity-policy application

1. Hard-suppression factors apply: the proven impact is self-only, and the only higher-impact story requires an unsupported hostile same-host principal plus sensitive served files.
2. Network weighting assigns low likelihood to a `localhost` vector absent a realistic lower-privileged attacker.
3. The reportability rule says to ignore localhost-only paths that are not part of a meaningful product/production surface and for which no realistic lower-privileged in-scope attacker is established.
4. Independently, the final matrix maps `impact=low` plus `likelihood=low` to `ignore`.

## Final decision

`ignore`. The documentation should still improve its cleanup wording, but the validated state is not meaningfully reportable as a security vulnerability under the supplied attack-path policy. No severity or priority is assigned.
