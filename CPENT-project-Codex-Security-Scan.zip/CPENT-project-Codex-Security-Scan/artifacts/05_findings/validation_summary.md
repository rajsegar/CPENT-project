# Validation Summary

All six deduped candidates were independently validated. Each has a saved per-candidate report and a final validation receipt. All six survive as reportable; no row remains deferred.

| Candidate ID | Ledger row ID | Instance key | Root control | Entrypoint/source | Sink/control | Method | Confidence | Disposition | Counterevidence / proof gap | Survives |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `CPENT-DOC-001` | `FAMILY-SECRETS` | `sensitive-evidence-handling:CPENT_Master_Roadmap_2026.md:196` | `CPENT_Master_Roadmap_2026.md:196-205` | Learner evidence requested at lines 116-118 | Tracked evidence template at lines 223-238 | Static workflow trace | 0.78 | reportable | Global policy and a separate private-log workflow reduce likelihood but do not control this tracked roadmap path | yes |
| `CS-DOC-CLEANUP-LOCAL-HTTP-001` | `FAMILY-CMD` | `incomplete-cleanup:Module-01-Principles/Mini-Report.md:184` | `Module-01-Principles/Mini-Report.md:179-185` | Copy-ready server command at lines 100-105 | Lingering localhost file server | Static command/state/cleanup trace | high | reportable | Loopback limits exposure; no sensitive served directory is proven | yes |
| `CPENT-DRIVE-SCREENSHOTS-M01` | `FAMILY-LINKS` | `external-sensitive-resource-link:Notes/CPENT_Modules_01_02.md:427` | `Notes/CPENT_Modules_01_02.md:427` | Public repository reader | Anonymous Drive folder listing | Signed-out browser reproduction | high | reportable | Image bodies were not opened; repository source description establishes purpose | yes |
| `CPENT-DRIVE-SCREENSHOTS-M02` | `FAMILY-LINKS` | `external-sensitive-resource-link:Notes/CPENT_Modules_01_02.md:428` | `Notes/CPENT_Modules_01_02.md:428` | Public repository reader | Anonymous Drive folder listing | Signed-out browser reproduction | high | reportable | Image bodies were not opened; repository source description establishes purpose | yes |
| `CS-TEMPLATE-RAW-EVIDENCE-GIT-001` | `FAMILY-SECRETS` | `sensitive-evidence-disclosure:Reports/Finding-Report-Template.md:31` | `Reports/Finding-Report-Template.md:29-31` | Raw screenshots/requests/logs | Tracked Markdown finding | Static template workflow trace | high | reportable | Global redaction policy reduces likelihood but is not invoked at the evidence field | yes |
| `CS-TEMPLATE-CLIENT-DATA-GIT-001` | `FAMILY-SECRETS` | `client-data-disclosure:Reports/Penetration-Test-Report-Template.md:7` | `Reports/Penetration-Test-Report-Template.md:5-45` | Real client/target/contact data | Tracked full-report Markdown and appendices | Static template workflow trace | high | reportable | TODO labels, classification, and global policy do not establish a do-not-commit or sanitized-copy boundary | yes |

## Validation conclusion

The Drive findings have direct public-interface reproduction. The other four are documentation-workflow flaws: the unsafe condition occurs when a beginner follows a repository-prescribed path and commits or retains the resulting state. No existing live credential or private client target was found, so severity must be calibrated to the exposed content and preconditions during attack-path analysis.
