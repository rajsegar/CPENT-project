# Validation Report: CPENT-DRIVE-SCREENSHOTS-M01

## Candidate

- Candidate ID: `CPENT-DRIVE-SCREENSHOTS-M01`
- Instance: `external-sensitive-resource-link:Notes/CPENT_Modules_01_02.md:427`
- Ledger row: `FAMILY-LINKS`
- Root control: `Notes/CPENT_Modules_01_02.md:427`
- Confidence: High
- Method: static source/control/sink trace plus anonymous browser reproduction

## Validation rubric

- [x] The repository describes the linked source as a Module 01 CPENT screenshot collection.
- [x] The exact folder locator is committed in public Markdown.
- [x] The folder renders to a signed-out visitor without an access request.
- [x] The public listing exposes shared PNG filenames and sizes consistent with a bulk screenshot collection.
- [x] No repository control prevents public link-holder access; the effective Drive ACL is permissive.

## Evidence and test notes

`Notes/CPENT_Modules_01_02.md:11` describes 73 screenshots, and line 427 publishes the corresponding Drive URL. A clean cloud browser opened that exact URL without authentication. The page title was `Principles and obj pT - Google Drive`; it displayed a separate `Iniciar sesión` link while also rendering a folder grid. At least 50 numbered shared PNG entries (`1.png` through `50.png`) and their sizes were visible in the initial listing. No file was opened or downloaded.

The earlier public-web opener did not reach Drive and produced a deferred result. The direct signed-out browser reproduction supersedes that environmental proof gap.

## Counterevidence and uncertainty

No credential or private target is directly present in the Markdown. The likely impact is unauthorized bulk disclosure of course/source material, not system compromise. The browser check did not inspect image contents; content classification is nevertheless strongly supported by the repository's own source description, the folder title, and the numbered image collection.

## Minimal remediation validation

Remove the folder URL from public Markdown and change Drive sharing to restricted. Recheck the same URL in a signed-out browser and require an access-denied or sign-in-only response.

## Closure

| Ledger row id | Instance key | Source anchor | Root control | Entrypoint/source | Sink/control | Disposition | Counterevidence or proof gap | Survives |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `FAMILY-LINKS` | `external-sensitive-resource-link:Notes/CPENT_Modules_01_02.md:427` | `Notes/CPENT_Modules_01_02.md:11` | `Notes/CPENT_Modules_01_02.md:427` | Public repository reader | Anonymous Drive folder listing | `reportable` | Image bodies were not opened; repository evidence establishes the collection's CPENT screenshot purpose | `yes` |
