# Validation Report: CS-TEMPLATE-CLIENT-DATA-GIT-001

## Candidate and instance

- **Candidate ID:** `CS-TEMPLATE-CLIENT-DATA-GIT-001`
- **Title:** Full report template collects client, target, contact, and evidence data without a Git-storage boundary
- **Ledger row ID:** `FAMILY-SECRETS`
- **Instance key:** `client-data-disclosure:Reports/Penetration-Test-Report-Template.md:7`
- **Affected entry fields:** `Reports/Penetration-Test-Report-Template.md:5-13`
- **Root control:** `Reports/Penetration-Test-Report-Template.md:27-45`
- **Sink:** `Reports/Penetration-Test-Report-Template.md:98-110`
- **Disposition:** `reportable`
- **Confidence:** High

## Method

Static source/control/sink validation of the full-report template, with focused countercontrol review of `SECURITY.md`, `AGENTS.md`, `CONTRIBUTING.md`, `README.md`, and the template's own classification, data-handling, cleanup, retest, and appendix fields. This instance was evaluated independently from the finding-template evidence issue because it collects engagement-wide client metadata, targets, contacts, timing, and inventories even if individual findings are sanitized.

## Validation rubric

- [x] **Source sensitivity:** The template is designed to receive client identity, author and assessment dates, real assets, testing windows, emergency contacts, evidence, asset inventories, and timelines.
- [x] **Workflow reachability:** `README.md:56-64` presents `Reports/` as the repository location for finding and full-report templates, and the file is a reusable Markdown report inside the Git tree.
- [x] **Local control strength:** `TODO`, `Confidential or Lab Use`, the blank data-handling field, and post-test cleanup checklist do not require a sanitized repository copy or prohibit storage of completed client reports in Git.
- [x] **Global countercontrol effectiveness:** Global policies favor synthetic examples and redaction, but the real-client option and lack of a local storage boundary leave an ambiguous, reachable workflow rather than enforcing a safe default.
- [x] **Sink and impact:** Expected completion can place client relationships, private targets, personnel details, timing, and evidence references in tracked Markdown and persistent Git history.

## Evidence

### Source fields and workflow

- `Reports/Penetration-Test-Report-Template.md:5-13` asks for “Client or lab,” assessment name, author, test dates, report date, and classification. “Client or lab” expressly supports a real-client completion path.
- `Reports/Penetration-Test-Report-Template.md:27-45` asks for in-scope assets, out-of-scope items, testing window, allowed and prohibited techniques, data-handling rules, and an emergency contact.
- `Reports/Penetration-Test-Report-Template.md:98-110` asks for retest evidence and appendices containing an asset list, evidence index, and timeline.
- `README.md:56-64` identifies `Reports/` as the project location for finding and full-report templates; no Reports-specific README or mandatory export/private-storage step mediates use.

### Local controls

- The `TODO` placeholders are unmistakably non-sensitive in the repository's default state, but their function is to be replaced. They prevent an accidental live value in the blank template, not unsafe storage of a completed copy.
- `Reports/Penetration-Test-Report-Template.md:13` offers `Confidential or Lab Use`. A confidentiality marking communicates handling intent but does not prevent Git tracking, publication, cloning, or history retention.
- `Reports/Penetration-Test-Report-Template.md:44` leaves “Data-handling rules” blank. It delegates the relevant control to the user without providing a safe default such as “client reports must stay outside this repository.”
- `Reports/Penetration-Test-Report-Template.md:85-91` includes useful teardown actions and sensitive-evidence transfer or destruction. It does not require redaction of the report, removal of client metadata, or verification that the completed report is outside Git.
- `Reports/Penetration-Test-Report-Template.md:100-110` continues to solicit evidence, asset, and timeline references after the cleanup section, confirming that the report itself remains a potential disclosure sink.

### Repository-wide countercontrols

- `SECURITY.md:17-23` requires redacting credentials and tokens, using synthetic examples, and keeping sensitive evidence out of Git. This is strong policy, but it does not resolve the template's express real-client mode or state whether all completed client reports and their metadata must stay outside Git.
- `AGENTS.md:17-20,72-78` forbids real customer data, private targets, and unredacted screenshots and requires report redaction. It is explicitly repository guidance for AI assistants, so it cannot be assumed to govern every human learner completing a report.
- `CONTRIBUTING.md:15-24,34-41` bans credentials, tokens, personal data, packet captures, and proprietary material and requires a sensitive-data check. It reduces commit risk for users who follow the contribution process, but does not explicitly cover client names, private asset inventories, testing windows, or confidential report retention.
- `README.md:102-105` tells contributors to keep examples synthetic and redact secrets. It is contributor-focused and does not explain how to handle the full template's explicit “Client or lab” branch.

## Source, control, sink, and outcome

- **Source:** Operator-supplied real engagement data: client identity, assessment name and dates, private assets, emergency contact details, testing constraints, evidence references, asset inventories, and timelines.
- **Control:** Safe blank `TODO` values, a confidentiality label, an optional data-handling field, global redaction policies, and post-test cleanup guidance.
- **Broken boundary:** None of those controls says that a real-client completed report must be created outside the repository or that only a fully sanitized derivative may enter Git.
- **Sink:** The populated Markdown report and its retest/evidence/appendix sections remain trackable in the repository.
- **Outcome:** Repository readers and later Git-history consumers can learn confidential client relationships, private targets, personnel details, testing windows, security evidence references, and assessment intelligence.

## Test notes

The exact template and only the identified countercontrols were reviewed statically; no target content was changed and no real client data was introduced. The finding-template candidate does not subsume this instance: sanitizing per-finding screenshots and snippets would not remove the full report's client identity, scope, contact, asset-list, timing, or evidence-index fields.

## Counterevidence

The repository currently contains only blank `TODO` placeholders and a classification choice, not live client data. Strong global policies clearly favor synthetic and redacted repository content. These facts reduce immediate impact and the chance of misuse by a careful contributor.

They do not defeat the path because the template explicitly offers real-client use, the handling field has no default, “Confidential” does not implement access control, and cleanup does not address Git sanitization. A beginner can reasonably interpret the template as intended for completion in place without encountering a contrary template-local instruction.

## Uncertainty

No completed real-client report was found or tested, so this is a preventive template-control issue rather than a current disclosure. Actual severity depends on whether users complete the file in the repository and which real values they insert. That conditional impact does not remove the validated source/control/sink path.

## Minimal next step

Add a prominent storage boundary before the document-control table: use synthetic lab values for any copy stored in this repository; create real-client reports only in an approved private location; never commit completed confidential reports; and sanitize client names, private assets, contacts, dates, evidence indexes, and timelines before creating a repository-safe derivative. Make the data-handling field default to this rule rather than leaving it blank.

## Validation closure

| Ledger row ID | Instance key | Advisory/source reference | Seed anchor | Root control | Entrypoint/source | Sink/control | Disposition | Counterevidence or proof gap | Survives |
|---|---|---|---|---|---|---|---|---|---|
| `FAMILY-SECRETS` | `client-data-disclosure:Reports/Penetration-Test-Report-Template.md:7` | N/A | N/A | `Reports/Penetration-Test-Report-Template.md:27-45` | Real-client metadata fields at `Reports/Penetration-Test-Report-Template.md:5-13` | Retest evidence and asset/evidence/timeline appendices at `Reports/Penetration-Test-Report-Template.md:98-110`, with no do-not-commit/sanitize boundary | `reportable` | Blank placeholders and strong global policy reduce current and future risk but do not resolve the template's explicit client mode or missing Git-storage boundary | `yes` |
