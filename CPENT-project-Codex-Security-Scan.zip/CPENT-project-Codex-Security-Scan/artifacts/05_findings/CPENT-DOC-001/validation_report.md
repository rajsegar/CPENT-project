# Validation Report: CPENT-DOC-001

## Finding

**Title:** Roadmap directs detailed lab evidence into tracked module files without a local redaction boundary  
**Candidate ID:** `CPENT-DOC-001`  
**Instance key:** `sensitive-evidence-handling:CPENT_Master_Roadmap_2026.md:196`  
**Ledger row ID:** `FAMILY-SECRETS`  
**Advisory/source reference:** None  
**Seed anchor:** None  
**Root control:** `CPENT_Master_Roadmap_2026.md:196-205`  
**Disposition:** `reportable`  
**Survives validation:** `yes`  
**Confidence:** 0.78 (medium-high, based on exact static document-workflow and Git-boundary evidence)  
**Likely severity:** Low. No sensitive value is currently present, and disclosure requires a learner to populate and commit the prescribed file; repository-wide policy reduces likelihood. The impact may be greater if real client access or evidence is inserted.

## Affected locations

- **Entrypoint/source:** `CPENT_Master_Roadmap_2026.md:116-118`
- **Root control:** `CPENT_Master_Roadmap_2026.md:196-205`
- **Evidence sink/content schema:** `CPENT_Master_Roadmap_2026.md:223-238`
- **Incomplete ignore control:** `.gitignore:18-23`

## Validation method

Static document-workflow analysis, bounded countercontrol review, and Git tracking/ignore verification. Runtime reproduction is not applicable to this static Markdown workflow.

## Rubric checklist

- [x] Confirm that the roadmap solicits values capable of containing private scope, target, identity, access, or evidence data.
- [x] Identify whether an exact, reachable workflow control sanitizes or diverts those values before repository storage.
- [x] Confirm that the prescribed evidence file is reachable as a Git-tracked repository path.
- [x] Test whether repository-wide policies or the separate private-log workflow defeat this exact roadmap instance.
- [x] Calibrate concrete impact, required user actions, and limiting conditions.

## Evidence observed

### Source

`CPENT_Master_Roadmap_2026.md:116-118` directs the learner to save every important command or request, output, screenshot, mistake, and fix. These are operator-controlled values and may contain targets, credentials or tokens in requests, identifiers, private output, or sensitive screenshot content.

### Root control

`CPENT_Master_Roadmap_2026.md:196-205` says to create only a fixed set of files for each module and explicitly names `Module-XX/03-Lab-Evidence.md`. The roadmap does not classify the completed file as private, route it to `evidence-private/`, require a sanitized repository copy, or reference a redaction policy at this collection point.

### Sink

`CPENT_Master_Roadmap_2026.md:223-238` supplies the schema for the prescribed file. It requests `Target/asset`, `Starting access`, `Command or HTTP request`, `Important output`, `Screenshot filename`, and `Final proof`. These fields preserve the sensitive source categories in a repository-local Markdown artifact.

The repository boundary is concrete:

- `README.md:6` identifies the GitHub project.
- Local Git configuration points `origin` at `https://github.com/rajsegar/CPENT-project.git`.
- `git ls-files` confirms the roadmap, `.gitignore`, and 26 module Markdown files are tracked.
- `git check-ignore -v --no-index -- Module-XX/03-Lab-Evidence.md` returned exit status 1 with no matching ignore rule, confirming that the prescribed file is not ignored.

### Countercontrols and why they do not defeat this instance

- `SECURITY.md:19-23` requires redaction and says sensitive evidence belongs outside Git. This is a strong repository-wide policy, but the roadmap does not reference it at the source, file-creation instruction, or evidence schema.
- `AGENTS.md:17-20,72-78` prohibits real credentials, customer data, private targets, unredacted screenshots, and requires report redaction. Its stated purpose is repository/assistant contribution guidance; it does not alter the roadmap's learner-facing storage path.
- `CONTRIBUTING.md:20-23,34-41` prohibits sensitive contributions and supplies a review checklist. This can catch a careful contributor but does not prevent or sanitize the roadmap-created file before it enters Git.
- `README.md:24-26` tells learners to use the shared lab and finding templates, and `README.md:104-105` repeats synthetic/redacted-content guidance. These are general entrypoint controls, not a storage instruction for `Module-XX/03-Lab-Evidence.md`.
- `Labs/README.md:3-4,12-26` defines a safe, distinct workflow: sanitized summaries in `Labs/`, restricted screenshots, and redaction before commit. The roadmap instead prescribes a file under `Module-XX/` and does not route the learner through `Labs/README.md`.
- `Templates/Lab-Template.md:21-24,37-40` limits the target and collection and requires an evidence folder with no real secrets. The roadmap embeds its own different evidence schema and does not reference this template at the affected lines.
- `Study-Plan-November-2026.md:49-51` explicitly directs a private study log using the shared lab template. That instruction defeats the separate study-plan workflow, but it does not defeat this roadmap-specific instance because the roadmap neither references the private log nor places `03-Lab-Evidence.md` in it.
- `.gitignore:18-23` ignores packet captures, browser archives, core dumps, and `evidence-private/`, but not the prescribed Markdown evidence file. Secrets, requests, output, and private targets can therefore remain in the tracked Markdown even when binary evidence is excluded.

A targeted search found no `redact`, `sanitize`, `private study log`, `evidence-private`, `do not commit`, `not in Git`, `SECURITY.md`, `CONTRIBUTING.md`, `Labs/README`, or `Lab-Template` reference anywhere in `CPENT_Master_Roadmap_2026.md`.

## Source/control/sink assessment

- **Source:** Learner-controlled lab or client evidence, including requests, output, targets, access details, screenshots, and proof.
- **Control:** Repository-wide redaction policies and safe sibling workflows exist, but no exact roadmap control redirects, sanitizes, or blocks the prescribed module-local evidence file.
- **Sink:** An unignored `Module-XX/03-Lab-Evidence.md` within the Git-backed module tree.
- **Reachable path:** Follow roadmap checklist -> collect comprehensive evidence -> create the mandated module file -> populate the embedded evidence schema -> stage or commit the unignored Markdown file.
- **Boundary:** Private or lab evidence crosses into a broadly shareable Git repository and persistent history.
- **Outcome:** Disclosure of private targets, access context, request/output data, screenshot metadata, or other sensitive lab/client evidence.
- **Preconditions:** Sensitive values are present; the learner follows this roadmap rather than the separate private-log workflow; the populated file is committed.

## What was tested

1. Read the candidate, discovery receipts, security guidance, and threat model.
2. Traced the exact roadmap source, file-creation control, and evidence schema.
3. Reviewed only the named nearby and root countercontrols needed to test the path.
4. Verified the proposed Markdown path against `.gitignore` with Git's own ignore matcher.
5. Verified that the roadmap and module Markdown tree are tracked and that no local roadmap reference invokes the safe sibling workflows.

## Remaining uncertainty

- No populated `Module-XX/03-Lab-Evidence.md` containing a live secret or private target exists in the reviewed tree.
- Actual impact depends on what a learner inserts and whether the learner commits the file.
- A learner who independently follows `SECURITY.md` or the private study-log instruction will avoid the disclosure, so these controls reduce likelihood even though they do not close the roadmap-specific path.

## Minimal next step

No further proof is needed to retain the documentation-control gap. To determine whether impact has already occurred, separately inspect Git history for populated roadmap-style evidence files or sensitive values. The direct remediation is to add an inline boundary beside the file tree and evidence template that keeps raw/private evidence in `evidence-private/` and permits only a sanitized summary in tracked module Markdown.

## Validation artifacts

- `artifacts/05_findings/CPENT-DOC-001/validation_report.md`
- `artifacts/05_findings/CPENT-DOC-001/candidate_ledger.jsonl`

## Validation closure

| Ledger row ID | Instance key | Advisory/source reference | Seed anchor file:line | Root-control file:line | Entrypoint/source | Sink/control | Disposition | Counterevidence or proof gap | Survives |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `FAMILY-SECRETS` | `sensitive-evidence-handling:CPENT_Master_Roadmap_2026.md:196` | None | None | `CPENT_Master_Roadmap_2026.md:196-205` | `CPENT_Master_Roadmap_2026.md:116-118` | `CPENT_Master_Roadmap_2026.md:223-238`; `.gitignore:18-23` | `reportable` | Global redaction policies and a separate private-log workflow reduce likelihood but are not referenced by or enforced on this roadmap-prescribed tracked file; no current sensitive value was found. | `yes` |
