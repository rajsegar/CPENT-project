# Attack-Path Analysis: CPENT-DOC-001

## Finding identity

- **Title:** Roadmap directs detailed lab evidence into tracked module files without a local redaction boundary
- **Candidate ID:** `CPENT-DOC-001`
- **Ledger row:** `FAMILY-SECRETS`
- **Instance:** `sensitive-evidence-handling:CPENT_Master_Roadmap_2026.md:196`
- **Validation result:** The roadmap-specific documentation control gap is validated.
- **Final policy decision:** `ignore`
- **Final severity:** None; the final severity-policy matrix suppresses the path.

## Preserved affected locations

| Label | Location | Evidence |
|---|---|---|
| `entrypoint` | `CPENT_Master_Roadmap_2026.md:116-118` | Directs the learner to save every important command/request, output, screenshot, mistake, and fix. |
| `root_control` | `CPENT_Master_Roadmap_2026.md:196-205` | Prescribes a repository-local `Module-XX/03-Lab-Evidence.md` file. |
| `sink` | `CPENT_Master_Roadmap_2026.md:223-238` | Requests target, starting access, requests, output, screenshot filename, and final proof. |
| `incomplete_control` | `.gitignore:18-23` | Ignores selected raw evidence formats and `evidence-private/`, but not the prescribed Markdown path. |

## Factual numbered attack path

1. A beginner follows the roadmap and preserves commands or requests, output, screenshots, mistakes, and fixes from a lab or authorized engagement (`CPENT_Master_Roadmap_2026.md:116-118`).
2. The roadmap directs that learner to create `Module-XX/03-Lab-Evidence.md` inside the Git-backed module tree (`CPENT_Master_Roadmap_2026.md:196-205`).
3. The learner populates the embedded schema with target/asset, starting access, HTTP requests, important output, screenshot filenames, and final proof (`CPENT_Master_Roadmap_2026.md:223-238`). Some of those operator-controlled values could contain credentials, private target details, personal data, client identifiers, or sensitive evidence, but no such value is present now.
4. The exact Markdown path is not ignored. `.gitignore:18-23` protects selected raw capture formats and the separate `evidence-private/` directory, but does not redirect or block `Module-XX/03-Lab-Evidence.md`.
5. To cross a confidentiality boundary, the learner must disregard or miss the repository-wide redaction/private-storage controls, stage the populated file, commit it, and push it to the GitHub repository.
6. Only after those operator-controlled actions can an unauthenticated repository reader obtain any inserted sensitive material from the current tree or persistent Git history.

## Attack Path Facts

- **Assumptions:** The learner uses actual sensitive evidence rather than synthetic lab data, follows this roadmap instead of the private-log workflow, misses the global redaction controls, and commits and pushes the file. None of those events is currently evidenced by a populated file or live secret.
- **Context:** The workflow is beginner-directed and the target path is a normal repository Markdown file. A meaningful boundary crossing is possible from private learner/client evidence to broadly shareable Git history, but it is conditional on learner insertion and authenticated repository-write actions.
- **In-Scope Status According to the Threat Model:** In scope as a documentation-product control issue. The threat model explicitly identifies learner evidence crossing into public Git history, completed templates containing real data, and report redaction as primary surfaces. There is no application runtime or remotely triggerable software vulnerability.
- **Exposure:** No sensitive evidence is exposed in the reviewed tree. The repository is identified as a GitHub project, and a later pushed commit would be broadly readable and persistent, but public exposure is a postcondition rather than current state.
- **Identity:** The writer is the learner or repository contributor with local file access and authenticated Git write/push authority. The eventual reader may be unauthenticated. No service identity, privileged runtime, or victim account is involved.
- **Cross-Boundary Behavior:** Conditional, not verified. Evidence crosses from a private lab/client context into public Git only if sensitive values are inserted and the learner commits and pushes the unignored file.
- **Vector:** `none` for creation of the disclosure: no attacker-controlled network request reaches a sink. Public/remote reading exists only after the authorized contributor creates the exposure.
- **Preconditions:** Sensitive values must be present; the learner must use the roadmap-specific module file rather than the private log; the learner must miss explicit global policies; and the learner must stage, commit, and push. The file-creation step is plausible because it is directly prescribed to beginners, but the sensitive-data and policy-bypass steps are not currently demonstrated.
- **Attacker Input Control:** No. The evidence values and Git actions are operator-controlled. A future public reader consumes the result but does not cause the repository write through this documentation path.
- **Category:** Potential sensitive-information exposure caused by incomplete local evidence-handling guidance (`CWE-200`).
- **Mitigations Already Present:** `SECURITY.md:17-23` requires redaction and stores sensitive evidence outside Git; `AGENTS.md:17-20,72-78` requires synthetic examples and secret/personal-data redaction; `CONTRIBUTING.md:20-23,34-41` bans sensitive contributions and requires review; `README.md:24-26,104-105` routes learners to shared templates and repeats redaction; `Study-Plan-November-2026.md:49-51` explicitly creates a private study log; `Labs/README.md:3-4,12-26` limits tracked labs to sanitized summaries; `Templates/Lab-Template.md:21-24,37-40` requires no real secrets and minimum evidence; `.gitignore:18-23` provides `evidence-private/` and excludes selected raw evidence.
- **Auth Scope:** Operator/developer-only for the security-relevant state change. A contributor must intentionally stage and push their own populated evidence file. Reading becomes public only after that protected write path succeeds.
- **Impact Surface:** Data/confidentiality and Git-history persistence. No availability, integrity, identity, code-execution, or production-control impact is present.
- **Target Reach:** One learner-created module evidence file per occurrence. Git history can persist a committed value, but no fleet, tenant, or live service is involved.
- **Secrets References:** None currently. The roadmap fields are capable of receiving secrets or private target details, but validation found no live secret, credential, or populated roadmap-style evidence file.
- **Counterevidence:** The repository has unusually explicit, repository-wide controls: redact credentials, never add private targets or unredacted screenshots, store sensitive evidence outside Git, use a private study log, keep only sanitized lab summaries, and use `evidence-private/`. These controls do not textually alter this exact roadmap template, so the documentation inconsistency is real, but they make accidental disclosure less likely and prevent treating the future-data scenario as an existing exposure.
- **Blindspots:** Future learner behavior, evidence sensitivity, staging choices, review effectiveness, repository visibility at the time of a future commit, and Git-history content outside the reviewed current-tree instance are not proven here.
- **Controls:** The missing local control is an inline instruction beside the file tree/template to keep raw evidence in `evidence-private/` and commit only a sanitized summary. Existing global controls already state that rule elsewhere.
- **Confidence:** High that the roadmap path is unignored and lacks an inline boundary; high that no current secret is demonstrated; medium confidence that a beginner would miss all global controls and commit sensitive material; high confidence in the final matrix result.

## Counterevidence challenges

| Field challenged | Strongest counterevidence | Result |
|---|---|---|
| Scope | `SECURITY.md`, `AGENTS.md`, and the threat model make evidence handling an intended product-security invariant. | The documentation gap remains in scope, but it is not an existing data breach or runtime vulnerability. |
| Vector | The only state-changing actor is an authorized learner/contributor writing and pushing their own evidence. | `none`; there is no attacker-triggerable request or untrusted-input channel that performs the commit. |
| Auth scope | Staging and pushing require local control of the learner's checkout and repository write credentials. | Operator/developer-only protected write path. |
| Exposure | No populated `03-Lab-Evidence.md`, live credential, private target, or client evidence was found. | Current exposure is absent; public disclosure is conditional. |
| Cross-boundary behavior | The private-to-public boundary is crossed only after sensitive insertion plus commit/push. | Plausible future workflow error, not a verified crossing. |
| Preconditions | The learner must ignore `SECURITY.md`, synthetic-data rules, contribution review, the private-log instruction, sanitized lab workflow, and `evidence-private/`. | The beginner-facing inline omission makes this conceivable, but multiple explicit controls materially reduce likelihood. |
| Impact | No current secret exists; typical training-lab targets and outputs may be synthetic or disposable. | Evidence-backed impact is limited to a guidance gap; serious disclosure depends on future content. |

## Impact calibration

**Impact: `low`.** The current repository contains no live secret or private target at this instance. The validated defect is an inline documentation-control omission. A future commit could expose more sensitive material, but impact severity cannot be based on an unobserved credential or client dataset that the learner has not inserted or pushed.

## Likelihood calibration

**Likelihood: `medium`.** The file and schema are explicitly prescribed to a beginner and the path is tracked, making the workflow error credible. Likelihood is not high because disclosure additionally requires sensitive rather than synthetic data, failure to follow several explicit repository-wide controls, and an authenticated commit/push action. This rating reflects the documentation workflow, not an attacker-triggerable exploit.

## Mechanical severity-policy application

1. The state-changing path is operator/developer-controlled and uses a protected repository-write path; there is no privilege-escalation delta.
2. No remote or local-network surface increases likelihood; public access begins only after the contributor creates the disclosure.
3. The current tree does not establish a live exposure or a realistic attacker-controlled path to cause one.
4. Independently, the final matrix maps `impact=low` plus `likelihood=medium` to `ignore`.

## Final decision

`ignore`. The inline roadmap should be harmonized with the repository's private-log and redaction controls, but without a live secret and with sensitive insertion plus authenticated commit/push required, this instance is not meaningfully reportable as a security vulnerability under the supplied final policy. No severity or priority is assigned.
