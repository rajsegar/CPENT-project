# Validation Report: CS-TEMPLATE-RAW-EVIDENCE-GIT-001

## Candidate and instance

- **Candidate ID:** `CS-TEMPLATE-RAW-EVIDENCE-GIT-001`
- **Title:** Finding template solicits raw security evidence without an in-template redaction or private-storage control
- **Ledger row ID:** `FAMILY-SECRETS`
- **Instance key:** `sensitive-evidence-disclosure:Reports/Finding-Report-Template.md:31`
- **Entrypoint:** `README.md:24-26`
- **Root control / sink:** `Reports/Finding-Report-Template.md:29-31`
- **Disposition:** `reportable`
- **Confidence:** High

## Method

Static source/control/sink validation of the exact beginner workflow, followed by focused countercontrol review of `SECURITY.md`, `AGENTS.md`, `CONTRIBUTING.md`, `Reports/Evidence-Log-Template.md`, and `Labs/README.md`. The assessment tested whether those controls are necessarily encountered and specifically prevent sensitive evidence from entering the Git-backed finding template.

## Validation rubric

- [x] **Entrypoint reachability:** `README.md:21-26` tells a beginner to run an authorized lab, record evidence, write a finding, and use this exact finding template when the lab produces an issue.
- [x] **Sensitive source and sink:** `Reports/Finding-Report-Template.md:29-31` requests screenshots, request/response snippets, commands, and logs, evidence forms that commonly carry tokens, cookies, identities, internal targets, and personal or client data.
- [x] **Point-of-entry control:** The 39-line finding template contains no redaction instruction, sensitive-field checklist, approved-private-storage requirement, or link to evidence-handling guidance.
- [x] **Countercontrol effectiveness:** Repository-wide policies require redaction, but none is a required or directly linked step between the README entrypoint and the template evidence field; they reduce likelihood without defeating reachability.
- [x] **Impact and counterevidence:** No live secret is currently present, so impact is conditional on user-supplied evidence, but expected beginner use can still persist sensitive material in tracked Markdown and Git history.

## Evidence

### Source and workflow reachability

- `README.md:21-22` instructs the learner to run the suggested exercise, then record evidence and write a short finding.
- `README.md:24-26` directly links `Reports/Finding-Report-Template.md` as the template to use for a reportable lab issue.
- `Reports/Finding-Report-Template.md:29-31` provides an Evidence section and says: “Add screenshots, request/response snippets, commands, or logs.”
- The template contains no local qualification requiring sanitized excerpts, `REDACTED` substitutions, synthetic targets, or private storage for raw evidence.

### Countercontrols

- `SECURITY.md:17-23` is the strongest countercontrol: it requires replacing credentials and tokens with `REDACTED`, avoiding sensitive raw evidence in Git, using synthetic examples, and storing sensitive evidence outside Git. The finding workflow does not link to this section or restate it where evidence is inserted.
- `AGENTS.md:17-20,72-78` prohibits real credentials, customer data, private targets, and unredacted screenshots and tells report authors to redact secrets and personal data. Its stated audience is AI assistants contributing to the repository, so it is not a dependable control for a beginner manually completing the linked report template.
- `CONTRIBUTING.md:15-24,34-41` bans credentials, tokens, personal data, and proprietary material and includes a sensitive-data review checkbox. It applies when users follow the contribution workflow, but the README's learning path does not require reading it before writing a finding.
- `Reports/Evidence-Log-Template.md:7-14` gives strong evidence-specific handling instructions, including redacting report copies and storing sensitive originals in an approved location. The finding template neither embeds nor links to this guidance.
- `Labs/README.md:3-4,12-23` limits its workspace to sanitized summaries, restricts screenshots, and requires redaction before commit. The root workflow points to `Templates/Lab-Template.md`, not `Labs/README.md`, and the finding template does not route evidence through this guide.

## Source, control, sink, and outcome

- **Source:** Lab screenshots, HTTP requests or responses, terminal commands, and logs containing operator- or target-controlled sensitive values.
- **Entrypoint:** The root beginner workflow at `README.md:24-26` sends users to the finding template after evidence collection.
- **Broken control:** No adjacent redaction/private-storage instruction exists at `Reports/Finding-Report-Template.md:29-31`; generic policies remain out-of-band.
- **Sink:** Sensitive values are pasted into a Markdown finding inside the broadly shareable Git repository.
- **Outcome:** Secrets, tokens, personal data, private targets, or client evidence can become available to repository readers and persist in Git history.

## Test notes

All necessary files were reviewed statically because this is a documentation-product control failure rather than runtime code. No target files were changed and no sensitive test data was created. The validation preserved the exact instance instead of treating safer sibling templates as if their controls were inherited automatically.

## Counterevidence

The repository has unusually clear global evidence-handling policies, and the separate evidence-log and lab guidance provide suitable redaction/private-storage language. These controls lower the probability that a careful contributor will make the mistake. They do not eliminate the candidate because expected beginner use can go directly from the README to the finding template, and Markdown links or textual inheritance do not enforce that a user reads or applies the separate controls.

The template currently contains only a synthetic `.local` affected-asset example and no live sensitive evidence. This means there is no present disclosure to report; the reportable issue is the reachable unsafe template workflow.

## Uncertainty

Actual impact depends on a learner inserting sensitive evidence and committing the completed Markdown file. Repository history does not establish how often users complete templates in place versus copying them to private storage. This affects likelihood and severity, not the existence of the missing point-of-entry control.

## Minimal next step

Add an instruction immediately under `Reports/Finding-Report-Template.md:29-31` requiring sanitized excerpts, replacement of credentials/tokens/client identifiers with `REDACTED`, and private approved storage for raw screenshots, logs, and full request/response captures. Link the evidence-log handling section so the safe workflow is directly reachable from the evidence field.

## Validation closure

| Ledger row ID | Instance key | Advisory/source reference | Seed anchor | Root control | Entrypoint/source | Sink/control | Disposition | Counterevidence or proof gap | Survives |
|---|---|---|---|---|---|---|---|---|---|
| `FAMILY-SECRETS` | `sensitive-evidence-disclosure:Reports/Finding-Report-Template.md:31` | N/A | N/A | `Reports/Finding-Report-Template.md:29-31` | `README.md:24-26` routes beginners with lab evidence into the template | Raw evidence is pasted into tracked Markdown without a point-of-entry redaction/private-storage instruction | `reportable` | Strong global policies and safer sibling guidance reduce likelihood but are neither required nor linked in this exact workflow; no live secret is currently present | `yes` |
