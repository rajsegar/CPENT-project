# Security Hardening Proposal: Make Publish-Safe Content an Enforced Boundary

## Decision

Decide how CPENT-project should distinguish material that is safe for a public Git repository from raw evidence, real-client reports, and externally stored source collections. The decision is not whether the four findings need tactical fixes—they do—but whether we also want a reusable boundary that prevents the next equivalent mistake.

## Executive Recommendation

We have three serious options:

1. **Local fixes and stronger review** patches the four affected paths with almost no workflow change.
2. **Publication gate plus private workspaces** keeps the repository lightweight while centralizing the safety decision. This is my recommendation under the current balanced constraints.
3. **External case and evidence system** removes real-client artifacts from the repository workflow entirely and is the strongest choice if client work becomes routine.

We should apply Option 1's tactical changes immediately even if we choose a later option. Option 2 is attractive because the recurring control is textual and inexpensive to check. What gives me pause is false-positive fatigue: the gate must be narrow, explain failures well, and provide a reviewed exception for genuinely public primary sources.

## Evidence

I inspected the affected revision, all four write-ups, their safe PoCs, and the existing policy files. The evidence supports one repeated invariant rather than four unrelated issues.

| Evidence | Finding or document | What it establishes |
| --- | --- | --- |
| `E-M02` | [Public Module 02 screenshot folder with bulk access](../../findings/public-drive-module-02-screenshots/public-drive-module-02-screenshots.md) | A tracked external locator plus permissive ACL exposed a 105-screenshot course collection and a bulk-download control. |
| `E-M01` | [Public Module 01 screenshot folder](../../findings/public-drive-module-01-screenshots/public-drive-module-01-screenshots.md) | The same publication/ACL pattern independently exposed another screenshot collection. |
| `E-CLIENT` | [Client report template lacks a Git-storage boundary](../../findings/report-template-client-data-git/report-template-client-data-git.md) | A client-capable tracked template collects private assets, contacts, timing, and evidence without a do-not-commit default. |
| `E-RAW` | [Finding template lacks point-of-entry evidence redaction](../../findings/finding-template-raw-evidence-git/finding-template-raw-evidence-git.md) | A beginner-facing Evidence field requests high-risk artifacts without carrying the repository's redaction/private-storage rule. |
| `E-COV` | Repository coverage ledger | Runtime vulnerability families are not applicable; publication safety is the dominant cross-cutting boundary. |

Observed: the repository already states the right policy in `SECURITY.md`, `AGENTS.md`, and `CONTRIBUTING.md`. Observed: the affected links and templates bypass that intent in ordinary tracked Markdown. Inferred: control ownership is dispersed across authors and reviewers rather than represented by one publish-safety check.

## Current Design And Failure Mode

Today a contributor can add a source link or populate a report using normal Markdown. Git sees no semantic difference between a public primary-source link and a capability-like link to restricted material, or between a blank template and a completed client report. The only decision point is human memory of policy text.

This design has two coupled failure modes. First, removing bytes from Git does not protect an external collection if the public repository publishes its locator and the remote ACL is permissive. Second, placing a blank template in Git does not protect a completed copy if the template never changes storage class when real data is inserted. The evidence shows both failures, so a durable design should own the public/private transition rather than repeating warnings ad hoc.

## Desired Invariants

- Every tracked external resource is intentionally public, primary, and reviewed; capability-like private-storage locators are rejected by default.
- Every tracked report or evidence document is synthetic or sanitized before staging.
- Raw evidence and completed real-client reports have an approved private destination that is outside Git and obvious from the template workflow.
- A historical locator remains safe because the external ACL denies anonymous access; URL secrecy is never the control.
- Publication checks fail with a precise path, reason, and approved remediation or exception route.

## Constraints And Non-Goals

The repository has no application runtime, dependency manager, or existing CI pipeline in the reviewed tree. We should not create a service simply to police Markdown. Performance and memory costs are therefore secondary to clarity and contributor friction. We are not designing client evidence retention policy, replacing Drive, or claiming that a linter can validate every remote ACL automatically. Tactical ACL changes and document fixes remain required.

## Before Architecture

The current structure lets one author move content directly from a lab or external store into public Git, with policy text as an advisory side channel.

```mermaid
flowchart TD
    A[Contributor or learner] --> B[Markdown and templates]
    B --> C[Git repository]
    B --> D[External Drive folders]
    E[Global policy text] -. remembered manually .-> A
    C --> F[Public readers]
    D --> F
```

The important edge is `B -> C`: no component decides whether the material has changed from private to publishable. The second unowned edge is `D -> F`, where an external ACL can contradict repository policy.

## Options

### Option 1: Local fixes and stronger review

We remove both Drive locators, restrict both folder ACLs, and place explicit storage/redaction language in the two templates. The strongest case for this option is proportionality: four Markdown changes and two ACL changes directly close the known paths, with no new tooling or process.

The residual concern is recurrence. Each future source list and evidence-collecting template must independently remember the same invariant. Review can work well in a small, stable repository, but the current findings demonstrate that clear root policy alone did not prevent drift.

```mermaid
flowchart TD
    A[Contributor or learner] --> B[Patched Markdown and templates]
    B --> C[Git repository]
    B --> D[Restricted Drive folders]
    E[Inline warnings] --> B
    C --> F[Public readers]
    D -. named users only .-> G[Authorized readers]
```

| Change | Before | After | Security consequence | Cost |
| --- | --- | --- | --- | --- |
| External links | Private-source locators tracked | Locators removed | Stops repository-mediated discovery | Small source edit |
| Drive ACL | Anonymous listing | Restricted named access | Historical IDs no longer grant access | One-time ACL review |
| Templates | Blank or remote policy | Inline storage/redaction rule | Safer author decision at data entry | Small documentation change |
| Enforcement | Reviewer memory | Reviewer memory plus local text | Known paths close; drift remains possible | Ongoing review attention |

Rollout is immediate and rollback is a source/ACL revert, although reverting the ACL would intentionally reopen exposure and should require explicit approval.

### Option 2: Publication gate plus private workspaces

We retain every tactical change from Option 1, then add a small repository-owned gate. The gate checks tracked Markdown for prohibited capability-like storage links, requires an explicit reviewed-public exception for allowed external folders, and verifies that report/evidence templates contain the required local storage and redaction invariant. We also define ignored `evidence-private/` and `reports-private/` workspaces and make templates direct real artifacts there.

The security gain comes from moving the decision to one owned boundary before Git publication. We do not need to infer whether every document is sensitive; instead, we check a few falsifiable properties tied directly to the findings. The linter should never scrape or authenticate to external services. Remote ACL verification remains a manual review item for an approved public-link exception and a post-remediation test for previously exposed locators.

```mermaid
flowchart TD
    A[Contributor or learner] --> B[Public Markdown]
    A --> P[Ignored private workspaces]
    B --> G[Publication-safety gate]
    G --> C[Git repository]
    D[Restricted external storage] --> U[Authorized readers]
    C --> F[Public readers]
```

| Change | Before | After | Security consequence | Cost |
| --- | --- | --- | --- | --- |
| Control owner | Every author/reviewer | One repository gate plus local template rules | Reduces control drift | Script ownership |
| Private drafts | Informal `evidence-private/` only | Documented evidence and report private paths | Makes correct destination obvious | Minor workflow change |
| External links | Any HTTPS link accepted | Restricted patterns rejected; public exceptions reviewed | Blocks repeated locator exposure | Possible false positives |
| Template safety | Policy in distant files | Required local invariant checked before publication | Protects each evidence sink | Lint maintenance |

The appealing part is that all checks are local, fast, and easy to roll back. Performance and memory overhead should be negligible because the repository has 47 small text files, but that expectation is source-derived, not measured. Reliability depends on deterministic parsing and useful error messages; an overly broad regex would cause bypasses or warning fatigue. We should introduce the gate in warning mode, fix the existing findings, then switch to blocking after one clean review cycle. Rollback is disabling the gate while preserving the tactical document and ACL fixes.

### Option 3: External case and evidence system

We declare this Git repository lab-only and move all real-client reports, raw evidence, contacts, scopes, and timelines into an approved case/evidence platform with access control, retention, and audit logging. Git retains only blank templates, synthetic examples, and sanitized learning summaries. A publication gate still prevents accidental private locators and populated reports, but it no longer needs to support a real-client branch.

This option creates the clearest boundary and becomes attractive if professional engagements are frequent. It also introduces the largest operational commitment: identity management, retention policy, backups, migration, incident response, and vendor or platform dependency. No evidence in the current scan proves that volume or governance need, so adopting it now could be architecture theatre rather than proportionate hardening.

```mermaid
flowchart TD
    A[Tester or learner] --> S[Case and evidence system]
    A --> B[Synthetic study content]
    B --> G[Publication-safety gate]
    G --> C[Git repository]
    S --> U[Authorized reviewers]
    C --> F[Public readers]
```

| Change | Before | After | Security consequence | Cost |
| --- | --- | --- | --- | --- |
| Real-client workflow | Client-capable Git template | External case system only | Removes client data from Git by design | Platform and migration work |
| Evidence access | Informal private location | Role-based case access | Better confidentiality and auditability | Identity/operations burden |
| Repository purpose | Study plus possible client branch | Explicit lab/synthetic-only | Simplifies publication policy | Compatibility change for users |
| Failure containment | Git history may retain errors | Case boundary contains private material | Narrows public blast radius | New trusted system |

Rollback requires exporting retained records to another approved private store; moving them back into Git is not a safe rollback. This asymmetry is appropriate for a foundational data-boundary decision, but it raises the bar for adoption.

## Comparison

| Dimension | Option 1: Local fixes | Option 2: Gate + private workspaces | Option 3: External system |
| --- | --- | --- | --- |
| Security | Closes four known paths; drift remains | Closes paths and prevents close variants | Strongest separation for real engagements |
| Performance | Neutral | Local text check; expected negligible | External workflow latency |
| Memory | Neutral | Bounded script state | External platform resources |
| Reliability | Depends on review | Deterministic gate can fail closed; false positives possible | Depends on external service availability |
| Operability | Lowest | Small linter/exception process | Highest: accounts, retention, audit, backup |
| Migration | Immediate | Incremental warning-to-block rollout | Move all real-client work and retrain users |
| Reversibility | High | High; retain tactical fixes | Lower; records must remain in approved private storage |

Option 1 wins when delivery speed is the only priority. Option 2 wins under the current evidence because it targets the repeated control without adding a service. Option 3 should win if the project formally supports ongoing client engagements, regulated evidence, or multiple collaborating testers.

## Recommendation

I recommend Option 2 after immediate Option 1 containment. It is the smallest design that changes control ownership: authors still write Markdown, but one gate and two explicit private destinations decide what may cross into public Git. The expected resource cost is modest, and rollback does not require weakening the tactical protections.

I would change this recommendation if a stakeholder confirms that real-client reporting is routine or subject to retention/audit requirements; then Option 3 becomes proportionate. Conversely, if contributions are single-author and rare, Option 1 may be acceptable provided the two exposed ACLs are fixed and a quarterly external-link review is owned.

## Evidence Coverage And Residual Risk

| Evidence | Option 1 | Option 2 | Option 3 | Tactical fix still required? |
| --- | --- | --- | --- | --- |
| `E-M02` — Public Module 02 screenshot folder | addresses | addresses + mitigates recurrence | addresses + isolates source storage | Yes: remove link and restrict ACL |
| `E-M01` — Public Module 01 screenshot folder | addresses | addresses + mitigates recurrence | addresses + isolates source storage | Yes: remove link and restrict ACL |
| `E-CLIENT` — Client report Git boundary | addresses | addresses + enforces destination | addresses by removing client branch | Yes: patch template now |
| `E-RAW` — Raw evidence field | addresses | addresses + enforces local invariant | mitigates through case storage | Yes: patch template now |

No option can retroactively make a published folder identifier secret. ACL restriction is mandatory. The publication gate also cannot recognize arbitrary sensitive prose or screenshots perfectly, so human review and secret scanning remain defense in depth.

## Migration And Rollout

1. Restrict both Drive folders and remove their public links.
2. Add template-local storage/redaction language and private workspace guidance.
3. Define the narrow gate rules and an allowlist format for reviewed public primary sources.
4. Run the gate in warning mode against the current tree and tune only evidence-backed false positives.
5. Enable blocking in pre-commit and CI after one clean review cycle.
6. Revalidate old links signed out and run all four finding PoCs against the fixed revision.

Rollback disables the gate but retains ACL and template changes. Any exception should identify an owner, purpose, review date, and proof that the external resource is intentionally public.

## Validation Plan

- Source tests: old Drive locators absent; report templates contain the required local boundary before sensitive fields.
- ACL tests: old URLs show an access gate signed out and never render filenames, sizes, or bulk controls.
- Gate tests: reject representative private folder links, populated confidential reports, and unsafe Evidence sections; accept blank templates and approved public primary sources.
- Reliability tests: clear diagnostics, deterministic exit codes, and no network dependency.
- Performance check: record elapsed time and peak memory over the full tracked tree before enabling CI blocking; reject the design only if contributor latency becomes material.
- Security regression: rerun the original four PoCs and the repository secret/target sweep.

## Implementation Work Packages

- **WP1 — Tactical containment:** ACL changes, link removal, template warnings, and retest.
- **WP2 — Private workspace contract:** ignored directories, copy workflow, sanitization checklist, and documentation.
- **WP3 — Publication-safety gate:** focused local rules, exceptions, fixtures, and clear diagnostics.
- **WP4 — Rollout:** warning mode, CI/pre-commit integration, ownership, and metrics.

Acceptance requires all four original findings to fail their vulnerable tests, old Drive URLs to deny signed-out access, private workspaces to be ignored, and the gate to pass the current safe tree without unexplained exceptions.

## Open Questions

- Is real-client reporting an intended supported use of this repository?
- Who owns approval and periodic review of public external-resource exceptions?
- Should the gate block locally, in CI, or both?
- What private storage satisfies the user's retention, encryption, backup, and collaboration needs?
- Does any Git history or fork still contain additional external source locators that need ACL review?
