# Security Hardening Review: CPENT-project

## Evidence Basis

This review is derived from a complete 47-file repository scan at revision `0229ad894c204d3b541825d46d8f95f86f59e3a5`. Two findings expose externally stored screenshot collections, and two report templates can carry sensitive material into Git without a local storage or redaction boundary. I inspected the four write-ups, their PoCs, the repository policies, and the affected Markdown directly.

The common condition is not an application bug. We currently rely on authors to remember a dispersed publication policy while editing otherwise ordinary Markdown. The same missing decision appears at two boundaries: whether an external resource is truly public, and whether a completed report is safe to publish.

## Constraints

- The repository is a small static Markdown knowledge base with no build or application runtime.
- No measured performance or memory budget was supplied; the relevant cost is contributor friction and false positives.
- Tactical fixes remain necessary immediately: remove both public folder locators, restrict their ACLs, and add local storage/redaction instructions to both templates.
- Proposals are design guidance only and do not close findings until implemented and revalidated.

## Opportunity Portfolio

| Opportunity | Evidence | Options | Recommendation | Proposal |
| --- | --- | --- | --- | --- |
| Make publish-safe content an enforced boundary | Public screenshot folders; client-report and raw-evidence template gaps | 1. Local fixes; 2. Policy gate plus private workspaces; 3. External case/evidence system | Use Option 2 after applying the tactical fixes | [Proposal](proposals/publish-safe-content-boundary.md) |

## Recommendation Summary

I recommend **Option 2: a repository publication gate with explicit private workspaces**. It fits the repository's scale: we keep Markdown and the current study workflow, but make two invariants machine-checkable before a push. External folder links require an explicit reviewed-public exception, and report/evidence templates must direct real material to ignored private paths while tracked copies remain synthetic or sanitized.

Option 1 is the fastest containment step and should happen first, but it leaves recurrence risk with the next template or source link. Option 3 becomes preferable only if this repository starts carrying routine client engagements or high-volume evidence; at the current scale, a separate case-management platform would add more operational burden than the evidence justifies.

## Next Decisions

1. Confirm whether real-client reporting is an intended supported workflow or whether the repository should be lab-only.
2. Select the allowed public-link policy and who may approve exceptions.
3. Decide whether pre-commit, CI, or both should enforce the publication gate.
4. After implementation, revalidate the two old Drive URLs signed out and rerun both template PoCs.
