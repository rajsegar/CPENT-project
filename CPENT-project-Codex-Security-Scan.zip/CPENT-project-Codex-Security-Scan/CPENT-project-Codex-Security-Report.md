# Security Review: rajsegar/CPENT-project

## Scope

Standard repository security scan of all 47 tracked files in the static CPENT learning knowledge base.

- Scan mode: repository
- Target kind: git_revision
- Target ID: target_sha256_b3a96fac48e989021dadf0414991c8c682fdb60588d06a46d677c794da58aaa2
- Revision: 0229ad894c204d3b541825d46d8f95f86f59e3a5
- Inventory strategy: repository
- Included paths: .
- Excluded paths: none
- Runtime or test status: No application runtime, build system, dependency manifest, CI/CD pipeline, infrastructure code, binary, archive, packet capture, macro, executable, or symlink is tracked.
- Artifacts reviewed: 47 regular text files, root safety and contribution policies, 14 module guides, study plans and templates, report templates and source links
- Scan context: The repository is a public-facing CPENT study knowledge base, so documentation safety, evidence handling, engagement confidentiality, and external source trust are the primary security surfaces.

Limitations and exclusions:
- External folder ACLs and contents can change after the observation time.
- No remote file body was opened or downloaded during validation.
- The supplied exam notes document was used only as supporting context and was not part of repository coverage.

### Scan Summary

| Field | Value |
| --- | --- |
| Reportable findings | 4 |
| Severity mix | high: 1, medium: 2, low: 1 |
| Confidence mix | high: 4 |
| Coverage | complete |
| Validation mode | Full static review plus bounded offline PoCs and authorized signed-out ACL observation for the two external screenshot folders. |

Canonical artifacts: `scan-manifest.json`, `findings.json`, and `coverage.json`. This report is a deterministic projection of those files.

## Threat Model

The main risk is publication of sensitive engagement material, proprietary training evidence, or capability-like external locators through ordinary Markdown and Git history; conventional runtime exploit classes are not applicable because the repository has no executable application surface.

### Assets

- learner authorization and operational safety
- course-content and source-material confidentiality
- client engagement and evidence confidentiality
- integrity of reusable penetration-testing guidance

### Trust Boundaries

- learner or contributor to public Git history
- public repository to externally hosted source material
- blank tracked template to populated engagement record
- raw evidence store to sanitized report derivative

### Attacker Capabilities

- unauthenticated repository browsing and cloning
- following stable external-resource locators
- retaining identifiers or documents from Git history
- reading accidentally committed reports or evidence

### Security Objectives

- keep real credentials, targets, client identities, and raw evidence outside public Git
- ensure externally linked non-public collections reject anonymous access
- make authorized scope, cleanup, redaction, and storage boundaries explicit at the point of use
- avoid unsafe copy-paste commands against public targets

### Assumptions

- The repository remains a static educational knowledge base.
- Concrete lab commands are intended only for authorized, learner-controlled systems.
- General repository policies are read and followed by careful contributors but are not enforcement mechanisms.

## Findings

| Finding | Severity | Confidence | Detailed write-up |
| --- | --- | --- | --- |
| [Module 02 source screenshots are anonymously listable through a published folder locator](#finding-1) | high | high | [Open report](findings/public-drive-module-02-screenshots/public-drive-module-02-screenshots.md) |
| [Module 01 source screenshots are anonymously listable through a published folder locator](#finding-2) | medium | high | [Open report](findings/public-drive-module-01-screenshots/public-drive-module-01-screenshots.md) |
| [Real-client penetration-test reports can be committed without a storage boundary](#finding-3) | medium | high | [Open report](findings/report-template-client-data-git/report-template-client-data-git.md) |
| [Finding template can carry unredacted evidence into Git history](#finding-4) | low | high | [Open report](findings/finding-template-raw-evidence-git/finding-template-raw-evidence-git.md) |

### Confidence Scale

| Label | Meaning |
| --- | --- |
| high | Direct evidence supports the finding with no material unresolved blocker. |
| medium | Evidence supports a plausible issue, but material runtime or reachability proof remains. |
| low | Evidence is incomplete and the item is retained only for explicit follow-up. |

<a id="finding-1"></a>

### [1] Module 02 source screenshots are anonymously listable through a published folder locator

| Field | Value |
| --- | --- |
| Severity | high |
| Confidence | high |
| Confidence rationale | The source classification and exact locator are committed, and a clean signed-out browser rendered the folder listing and Download all control without opening or downloading a file. |
| Category | sensitive-data-exposure |
| CWE | CWE-200 |
| Affected lines | Notes/CPENT_Modules_01_02.md:12, Notes/CPENT_Modules_01_02.md:428 |

#### Summary

See the [detailed technical write-up](findings/public-drive-module-02-screenshots/public-drive-module-02-screenshots.md).

#### Validation

See the [detailed technical write-up](findings/public-drive-module-02-screenshots/public-drive-module-02-screenshots.md).

#### Dataflow

See the [detailed technical write-up](findings/public-drive-module-02-screenshots/public-drive-module-02-screenshots.md).

#### Reachability

See the [detailed technical write-up](findings/public-drive-module-02-screenshots/public-drive-module-02-screenshots.md).

#### Severity

See the [detailed technical write-up](findings/public-drive-module-02-screenshots/public-drive-module-02-screenshots.md).

#### Remediation

See the [detailed technical write-up](findings/public-drive-module-02-screenshots/public-drive-module-02-screenshots.md).

<a id="finding-2"></a>

### [2] Module 01 source screenshots are anonymously listable through a published folder locator

| Field | Value |
| --- | --- |
| Severity | medium |
| Confidence | high |
| Confidence rationale | The source classification and locator are committed, and a clean signed-out browser rendered at least 50 numbered shared PNG entries with a separate sign-in affordance. |
| Category | sensitive-data-exposure |
| CWE | CWE-200 |
| Affected lines | Notes/CPENT_Modules_01_02.md:11, Notes/CPENT_Modules_01_02.md:427 |

#### Summary

See the [detailed technical write-up](findings/public-drive-module-01-screenshots/public-drive-module-01-screenshots.md).

#### Validation

See the [detailed technical write-up](findings/public-drive-module-01-screenshots/public-drive-module-01-screenshots.md).

#### Dataflow

See the [detailed technical write-up](findings/public-drive-module-01-screenshots/public-drive-module-01-screenshots.md).

#### Reachability

See the [detailed technical write-up](findings/public-drive-module-01-screenshots/public-drive-module-01-screenshots.md).

#### Severity

See the [detailed technical write-up](findings/public-drive-module-01-screenshots/public-drive-module-01-screenshots.md).

#### Remediation

See the [detailed technical write-up](findings/public-drive-module-01-screenshots/public-drive-module-01-screenshots.md).

<a id="finding-3"></a>

### [3] Real-client penetration-test reports can be committed without a storage boundary

| Field | Value |
| --- | --- |
| Severity | medium |
| Confidence | high |
| Confidence rationale | The storage transition is directly visible in the tracked template and Git ignore behavior, and an offline synthetic PoC demonstrates that a populated report remains staging-eligible without using real client data. |
| Category | sensitive-data-exposure |
| CWE | CWE-200 |
| Affected lines | Reports/Penetration-Test-Report-Template.md:5-13, Reports/Penetration-Test-Report-Template.md:27-45, Reports/Penetration-Test-Report-Template.md:98-110 |

#### Summary

See the [detailed technical write-up](findings/report-template-client-data-git/report-template-client-data-git.md).

#### Validation

See the [detailed technical write-up](findings/report-template-client-data-git/report-template-client-data-git.md).

#### Dataflow

See the [detailed technical write-up](findings/report-template-client-data-git/report-template-client-data-git.md).

#### Reachability

See the [detailed technical write-up](findings/report-template-client-data-git/report-template-client-data-git.md).

#### Severity

See the [detailed technical write-up](findings/report-template-client-data-git/report-template-client-data-git.md).

#### Remediation

See the [detailed technical write-up](findings/report-template-client-data-git/report-template-client-data-git.md).

<a id="finding-4"></a>

### [4] Finding template can carry unredacted evidence into Git history

| Field | Value |
| --- | --- |
| Severity | low |
| Confidence | high |
| Confidence rationale | The README-to-template path and missing point-of-entry guard are explicit, and a safe synthetic disposable-repository PoC confirms an evidence-bearing copy remains Git-eligible. |
| Category | sensitive-data-exposure |
| CWE | CWE-200 |
| Affected lines | README.md:24-26, Reports/Finding-Report-Template.md:29-31 |

#### Summary

See the [detailed technical write-up](findings/finding-template-raw-evidence-git/finding-template-raw-evidence-git.md).

#### Validation

See the [detailed technical write-up](findings/finding-template-raw-evidence-git/finding-template-raw-evidence-git.md).

#### Dataflow

See the [detailed technical write-up](findings/finding-template-raw-evidence-git/finding-template-raw-evidence-git.md).

#### Reachability

See the [detailed technical write-up](findings/finding-template-raw-evidence-git/finding-template-raw-evidence-git.md).

#### Severity

See the [detailed technical write-up](findings/finding-template-raw-evidence-git/finding-template-raw-evidence-git.md).

#### Remediation

See the [detailed technical write-up](findings/finding-template-raw-evidence-git/finding-template-raw-evidence-git.md).

## Structural Hardening

The scan also produced derived, unsealed design guidance based on the complete finding collection. These proposals describe options and tradeoffs; they do not indicate that any finding has been remediated.

[Open the structural hardening portfolio](hardening/hardening.md)

## Reviewed Surfaces

| Surface | Risk Area | Outcome | Notes |
| --- | --- | --- | --- |
| External screenshot and source links | Repository-to-external-storage confidentiality | Reported | Two public Drive folder locators survived validation; signed-out access exposed folder listings, and Module 02 presented a bulk-download control. Evidence: artifacts/05_findings/validation_summary.md, artifacts/05_findings/CPENT-DRIVE-SCREENSHOTS-M01/validation_report.md, artifacts/05_findings/CPENT-DRIVE-SCREENSHOTS-M02/validation_report.md |
| Finding and full-report templates | Sensitive evidence and client data in Git history | Reported | Two template instances lack point-of-entry private-storage or redaction boundaries; no live client secret is currently committed. Evidence: artifacts/05_findings/validation_summary.md, artifacts/05_findings/CS-TEMPLATE-CLIENT-DATA-GIT-001/validation_report.md, artifacts/05_findings/CS-TEMPLATE-RAW-EVIDENCE-GIT-001/validation_report.md |
| Root roadmap evidence workflow | Sensitive evidence in tracked module files | Rejected | No live secret is present, strong repository-wide controls exist, and a contributor commit and push are required; final policy did not report it. Evidence: artifacts/05_findings/CPENT-DOC-001/validation_report.md, artifacts/05_findings/CPENT-DOC-001/attack_path_analysis_report.md |
| Command-bearing study content | Unsafe copy-paste execution | Rejected | No pipe-to-shell, destructive, persistence, evasion, denial-of-service, or public-target command path survived. The localhost cleanup candidate was self-only and ignored. Evidence: artifacts/02_discovery/finding_discovery_report.md, artifacts/05_findings/CS-DOC-CLEANUP-LOCAL-HTTP-001/attack_path_analysis_report.md |
| Authorization and scope safety | Unauthorized testing guidance | No issue found | Concrete examples use loopback or clear placeholders; modules consistently require written authorization, rules of engagement, minimal impact, stop conditions, and cleanup. Evidence: artifacts/02_discovery/finding_discovery_report.md, artifacts/03_coverage/repository_coverage_ledger.md |
| Secrets and private target inventory | Existing committed credentials or evidence | No issue found | No credential, token, private key, JWT, password assignment, real client identity, or public attack target was found in the tracked tree. Evidence: artifacts/02_discovery/finding_discovery_report.md, artifacts/03_coverage/repository_coverage_ledger.md |
| Executables and sensitive artifact types | Malicious or unreviewed binary content | Not applicable | The tree contains only regular text files; no executables, symlinks, archives, captures, macro-enabled documents, or binaries are tracked. Evidence: artifacts/03_coverage/repository_coverage_ledger.md |
| Conventional application and platform vulnerability families | Injection, deserialization, SSRF, path and file processing, authentication, and platform controls | Not applicable | No application runtime, database, parser, network client, authentication system, file-processing service, dependency manifest, CI/CD, infrastructure code, or agent runtime exists. Evidence: artifacts/03_coverage/repository_coverage_ledger.md |

## Open Questions And Follow Up

- Are the screenshot collections authorized for anonymous public distribution?
  - Follow-up prompt: Confirm ownership and licensing, then restrict ACLs unless public redistribution is explicitly authorized.
- Is real-client reporting an intended supported workflow for this public repository?
  - Follow-up prompt: If yes, define the approved private report and evidence destination and enforce a sanitized-public-copy workflow.
