# Real-client penetration-test reports can be committed without a storage boundary

## Executive Summary

The reusable penetration-test report template supports both laboratory and real-client
engagements, but it does not tell the author that a completed client report must remain
outside Git. The same tracked Markdown file asks for client identity, private assets,
testing dates, emergency contacts, evidence references, asset inventories, and a
timeline. Its `Confidential or Lab Use` label and cleanup checklist do not prevent a
populated report from being staged, published, cloned, or retained in history.

If a learner completes the explicit client branch in the repository and commits the
result, an unauthenticated repository reader may obtain confidential engagement
metadata and evidence. The potential impact is high, but exploitation requires a
real-client completion, a repository-local save, a commit, and failure to follow the
separate root policies. We therefore rate the vulnerability **Medium (P2)** under the
project's severity policy: high impact combined with medium likelihood.

Revision `0229ad894c204d3b541825d46d8f95f86f59e3a5` is affected. No fixed revision was
available for comparison, and the introduction point was not established in this
focused review. I statically reviewed the vulnerable revision and its report-writing
workflow, then ran the included local PoC with clearly synthetic values. I did not use,
seek, or access a live client report, and the PoC did not alter the target repository.

| Attribute | Assessment |
| --- | --- |
| Vulnerability class | CWE-200: Exposure of Sensitive Information |
| Affected component | `Reports/Penetration-Test-Report-Template.md` |
| Affected revision | `0229ad894c204d3b541825d46d8f95f86f59e3a5` |
| Severity | Medium |
| Priority | P2 |
| Current disclosure observed | No; the checked-in template contains placeholders only |

## Background

This repository is a beginner-oriented study knowledge base. `README.md` presents the
`Reports/` directory as the location for finding and full-report templates. The full
template is consequently both reusable content and a tracked file inside the same Git
tree where a learner may be writing.

The document starts with fields intended to become engagement metadata:

```markdown
<!-- Reports/Penetration-Test-Report-Template.md:5-13 -->
| Field | Value |
| --- | --- |
| Client or lab | TODO |
| Assessment name | TODO |
| Version | 0.1 Draft |
| Author | TODO |
| Test dates | TODO |
| Report date | TODO |
| Classification | Confidential or Lab Use |
```

Two details matter. First, `Client or lab` explicitly supports a real engagement rather
than limiting the template to synthetic exercises. Second, `Confidential or Lab Use`
is a classification choice, not an access-control mechanism. Once we replace these
placeholders, Git treats the populated Markdown exactly like the safe blank template.

The repository does have strong general rules. `SECURITY.md` says to use synthetic
names and lab-only addresses and to keep sensitive evidence outside Git. `AGENTS.md`
forbids customer data, private targets, and unredacted screenshots, while
`CONTRIBUTING.md` requires sensitive data to be absent or redacted. These controls are
valuable, but the client-capable template neither links to them nor translates them
into a mandatory output location or sanitization step.

The required invariant is therefore simple: **a Git-tracked copy may contain only
synthetic lab data or a deliberately sanitized derivative; a completed real-client
report must be created and retained in approved private storage.**

## Vulnerability Details

### The template gathers engagement-wide sensitive data

After document control, we reach the scope and rules-of-engagement section:

```markdown
<!-- Reports/Penetration-Test-Report-Template.md:27-45 -->
## Scope and rules of engagement

### In scope

| Asset | Type | Notes |
| --- | --- | --- |
| TODO | TODO | TODO |

### Out of scope

- TODO

### Constraints

- Testing window:
- Allowed techniques:
- Prohibited techniques:
- Data-handling rules:
- Emergency contact:
```

If we carry a real-client choice into this section, the blank fields naturally become
private hostnames or addresses, scheduling information, security constraints, and a
named contact. The `Data-handling rules` entry looks like a guard, but its default is
empty. It delegates the decisive security rule to the beginner instead of establishing
a safe repository default.

The report then retains engagement metadata after its cleanup section:

```markdown
<!-- Reports/Penetration-Test-Report-Template.md:85-110 -->
## Cleanup and post-testing actions

- [ ] Test artifacts removed.
- [ ] Temporary accounts or credentials removed.
- [ ] Configuration changes restored.
- [ ] Sensitive evidence transferred or destroyed as agreed.
- [ ] Client or lab owner notified of completion.

## Limitations

State anything that reduced coverage, including time, unavailable systems,
excluded techniques, unstable targets, or incomplete credentials.

## Retest

| Finding | Status | Evidence | Date |
| --- | --- | --- | --- |
| TODO | Fixed, partial, or open | TODO | TODO |

## Appendices

- Asset list
- Tool list and versions
- Evidence index
- Severity model
- Timeline
```

The cleanup items are appropriate for the tested environment, but they do not clean the
report. From here we are still instructed to add evidence, an asset inventory, and an
attack timeline. Even if raw packet captures are stored elsewhere, the index and
timeline can reveal targets, finding names, internal structure, and the chronology of
an authorized assessment.

### The missed transition is storage, not collection

The vulnerable transition is easiest to see as three document states:

| State | Data | Git behavior | Security result |
| --- | --- | --- | --- |
| Blank template | Obvious placeholders | Tracked | Safe |
| Completed client report | Client, target, contact, timing, and evidence metadata | Still trackable | Confidential data is one staging action from publication |
| Sanitized derivative | Synthetic or deliberately redacted values | Trackable | Safe when the sanitization is complete |

Nothing between the first and second states requires the third. We can label the second
state `Confidential`, but that label does not change file permissions, ignore matching,
Git staging, remote visibility, or history retention. Similarly, a root-level policy
works only if the author remembers and correctly applies it at every field.

The resulting path is:

1. We choose `Client` rather than `lab` and replace the document-control placeholders.
2. We populate real scope, timing, contact, retest, and appendix fields.
3. No template-local warning redirects the file to private storage or demands a
   sanitized derivative.
4. We save or copy the completed file under the Git worktree and commit it.
5. Repository readers and later history consumers obtain the engagement data.

This is a preventive control defect rather than evidence of a current incident. At the
reviewed revision the fields are still placeholders, and no live client data was used
to validate the path.

## Exploitability Analysis

### Strongest realistic route

The strongest route is accidental disclosure during ordinary report writing. A learner
starts with the repository's own reusable template, sees that `Client or lab` permits
real work, and completes the Markdown near the original. Because the file extension and
directory are already ordinary Git content, the populated report remains eligible for
staging. After a push, the reader's part is trivial: clone or browse the repository and
retain the report even if the latest branch is later cleaned.

This route does not require a remote attacker to control the report fields. The trusted
tester supplies them, and the unauthenticated reader benefits after publication. That
distinction matters for likelihood: the reader has a remote, low-friction path, but the
initial exposure still requires several operator actions.

The most useful disclosure primitives are cumulative:

- document control identifies a client relationship, author, and assessment dates;
- scope fields enumerate private targets and excluded systems;
- constraints reveal testing windows, allowed techniques, and an emergency contact;
- retest rows disclose unresolved findings and their verification dates;
- appendices correlate assets, evidence names, tooling, and attack chronology.

One filled field may be low impact, while the full report can provide a coherent map of
the engagement. A token pasted into evidence would increase impact further, but we do
not need that stronger and unproven case for this finding.

### Alternative routes and constraints

A completed report might be committed under a different filename rather than replacing
the template. That changes neither the root cause nor the Git boundary. It may also be
attached to an issue or copied to another broadly shared repository; those are plausible
variants, but the PoC stays with the direct tracked-file route evidenced by source.

Several facts constrain exploitation:

- the checked-in template is currently safe because all sensitive fields are blank;
- the author must use a real engagement, populate the fields, and publish the result;
- `SECURITY.md` and contribution checks may stop a careful author or reviewer;
- branch protection, review, or external pre-commit tooling may catch some disclosures;
- there is no evidence of an existing client report, credential, or private target.

These constraints reduce likelihood to medium. They do not close the workflow because
none is an exact template-local storage control, and common secret scanners cannot
reliably identify a client name, private hostname, emergency contact, or testing window.
With high potential confidentiality impact and medium likelihood, the project matrix
mechanically produces a Medium (P2) result.

## Proof of Concept

The PoC is a safe workflow probe, not a client-data sample. It reads the template and
`.gitignore` from the vulnerable revision, copies both into a disposable temporary Git
repository, and inserts only unmistakably synthetic markers. We then test two properties:

1. the populated report contains no inline instruction such as `never commit` or
   `approved private storage`; and
2. Git's own ignore matcher still considers the populated Markdown eligible for staging.

Run it from the unpacked report directory:

```sh
cd poc
./reproduce.sh <path-to-CPENT-project-checkout>
```

Representative output from the vulnerable revision is:

```text
[+] loaded vulnerable revision into a disposable Git repository
[+] inserted synthetic client, target, contact, and evidence markers
[+] no inline Git-storage boundary found in the populated template
[+] populated report is not ignored
[+] git would stage Reports/Penetration-Test-Report-Template.md
[+] target repository unchanged; temporary workspace removed
```

The probe creates no client data, makes no network request, and never writes inside the
target checkout. A shell trap removes its temporary repository on success, failure, or
interruption. `poc/README.md` documents prerequisites, the exact run command, expected
fixed behavior, and manual cleanup if a process is forcibly terminated before the trap
runs.

## Remediation

The minimal fix is to put the storage invariant directly before the first fillable
field and make the data-handling default explicit. For example:

```markdown
> **Storage boundary:** Use only synthetic lab values in any copy stored in this
> repository. Never commit a completed real-client report. Create and retain client
> reports in approved private storage. Before committing a repository-safe derivative,
> sanitize client names, private assets, contacts, dates, evidence references, and
> timelines.

## Document control
...

- Data-handling rules: Real-client reports remain outside Git; repository copies must
  be synthetic or sanitized according to the storage boundary above.
```

This fix turns an optional blank into a safe default and places the warning before the
user chooses the client branch. It also distinguishes raw/private evidence from a
sanitized report summary; redacting only credentials is not enough when asset and
engagement metadata are themselves confidential.

Useful structural hardening includes:

- split the laboratory example from a client-report template, with the latter carrying
  an unavoidable private-storage banner;
- provide a dedicated ignored directory such as `reports-private/` for local drafts,
  while keeping only blank templates and sanitized examples under `Reports/`;
- add a pre-commit or CI rule that rejects new populated confidential reports under
  tracked report paths;
- add a sanitization checklist covering client identity, targets, contacts, dates,
  evidence indexes, timelines, credentials, and screenshots;
- teach report cleanup as two separate operations: target teardown and document
  sanitization/storage verification.

Regression tests should cover the original path and nearby variants:

1. assert that the storage-boundary text appears before `Client or lab`;
2. assert that `Data-handling rules` has a non-empty safe default;
3. copy the template, populate synthetic client-style fields, and confirm the warning
   remains visible in the completed copy;
4. reject a tracked report marked `Confidential` when client/asset/contact fields are
   populated and no explicit sanitized marker is present;
5. allow the blank template and clearly synthetic lab examples;
6. verify that appendix and retest sections repeat or link back to the same boundary.

After applying the minimal text fix, the included PoC should stop at the boundary check
instead of reporting a vulnerable staging path. A separate regression test should then
exercise any chosen ignored private-report directory with `git check-ignore`.

## Summary

The full-report template crosses from a safe blank artifact to a potentially
confidential client report without changing its Git storage behavior. We can populate
client identity, private scope, contacts, timing, evidence, and timeline fields, yet no
local invariant requires the result to leave the repository or become a sanitized
derivative. A classification label and target-cleanup checklist do not implement that
boundary, while root policy is too distant to make the client branch safe by default.

The included PoC demonstrates the defect without client data or repository mutation:
synthetic completion leaves the Markdown unignored and eligible for staging, and the
template contains no inline private-storage warning. The practical fix is small—state
and default the storage boundary before collection begins—then reinforce it with an
ignored private workspace, commit-time checks, and regression coverage for populated
report variants.

