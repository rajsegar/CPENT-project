# Synthetic report-template storage-boundary PoC

This PoC demonstrates the report-template workflow using only synthetic values. It
does not access client data, make network requests, or modify the target checkout.

## What it tests

The script reads `Reports/Penetration-Test-Report-Template.md` and `.gitignore` from
vulnerable revision `0229ad894c204d3b541825d46d8f95f86f59e3a5`. In a temporary Git
repository it:

1. inserts an unmistakably synthetic client, RFC 5737 test address, `.invalid`
   contact, future dates, and synthetic evidence names;
2. verifies that the populated template has no inline warning such as `never commit`
   or `approved private storage`;
3. asks Git whether the report is ignored; and
4. uses a dry-run staging command to show that Git would add the populated Markdown.

The temporary repository is removed automatically. The source checkout is read with
`git show` and is never written.

## Requirements

- Bash
- Git
- GNU or compatible `sed`, `grep`, `mktemp`, and standard core utilities
- A local checkout containing the vulnerable revision

## Run

From the report directory:

```sh
cd poc
chmod +x reproduce.sh
./reproduce.sh <path-to-CPENT-project-checkout>
```

The vulnerable revision is the default. To probe a proposed fixed revision, pass its
commit or tag as the second argument:

```sh
./reproduce.sh <path-to-CPENT-project-checkout> <fixed-revision>
```

## Expected vulnerable output

```text
[+] loaded vulnerable revision into a disposable Git repository
[+] inserted synthetic client, target, contact, and evidence markers
[+] no inline Git-storage boundary found in the populated template
[+] populated report is not ignored
[+] git would stage Reports/Penetration-Test-Report-Template.md
[+] target repository unchanged; temporary workspace removed
```

## Expected fixed behavior

A minimally fixed template should include an inline instruction containing language
such as `Never commit a completed real-client report` and `approved private storage`
before the document-control fields. Against that revision, the script should stop with:

```text
[-] inline Git-storage boundary found; target does not match the vulnerable template
```

If the project also introduces a dedicated ignored location for completed private
reports, a companion regression test should run `git check-ignore` on a file in that
location and require a successful ignore match.

## Cleanup

Normal runs clean up automatically on success, failure, interruption, or termination.
If the process is killed in a way that prevents shell traps from running, remove any
directory matching this pattern from the operating system's temporary directory:

```text
report-template-client-data-git.*
```

No cleanup is required in the target checkout.
