#!/usr/bin/env bash
set -euo pipefail

DEFAULT_REVISION="0229ad894c204d3b541825d46d8f95f86f59e3a5"
TEMPLATE_PATH="Reports/Penetration-Test-Report-Template.md"
BOUNDARY_PATTERN='do not commit|never commit|outside (of )?git|approved private (location|storage)|saniti[sz]ed (copy|derivative)|repository-safe'

usage() {
  echo "Usage: $0 <path-to-CPENT-project-checkout> [revision]" >&2
  exit 2
}

[[ $# -ge 1 && $# -le 2 ]] || usage

REPO_ROOT=$1
REVISION=${2:-$DEFAULT_REVISION}
git -C "$REPO_ROOT" cat-file -e "$REVISION^{commit}"
git -C "$REPO_ROOT" cat-file -e "$REVISION:$TEMPLATE_PATH"
git -C "$REPO_ROOT" cat-file -e "$REVISION:.gitignore"

WORKDIR=$(mktemp -d "${TMPDIR:-/tmp}/report-template-client-data-git.XXXXXX")
cleanup() {
  rm -rf -- "$WORKDIR"
}
trap cleanup EXIT
trap 'exit 130' HUP INT TERM

mkdir -p "$WORKDIR/Reports"
git -C "$REPO_ROOT" show "$REVISION:$TEMPLATE_PATH" > "$WORKDIR/$TEMPLATE_PATH"
git -C "$REPO_ROOT" show "$REVISION:.gitignore" > "$WORKDIR/.gitignore"
git -C "$WORKDIR" init -q

REPORT="$WORKDIR/$TEMPLATE_PATH"

sed -i \
  -e 's/| Client or lab | TODO |/| Client or lab | SYNTHETIC CLIENT - TRAINING ONLY |/' \
  -e 's/| Assessment name | TODO |/| Assessment name | SYNTHETIC-ASSESSMENT-001 |/' \
  -e 's/| Author | TODO |/| Author | TEST_USER |/' \
  -e 's/| Test dates | TODO |/| Test dates | 2099-01-01 to 2099-01-02 |/' \
  -e 's/| Report date | TODO |/| Report date | 2099-01-03 |/' \
  -e 's/| Classification | Confidential or Lab Use |/| Classification | SYNTHETIC LAB USE ONLY |/' \
  -e 's/| TODO | TODO | TODO |/| 192.0.2.10 | Synthetic lab host | TEST-NET-1 only |/' \
  -e 's/^- Testing window:$/- Testing window: 2099-01-01 09:00-17:00 UTC/' \
  -e 's/^- Data-handling rules:$/- Data-handling rules: SYNTHETIC DATA ONLY/' \
  -e 's/^- Emergency contact:$/- Emergency contact: test-contact@example.invalid/' \
  -e 's/| TODO | Fixed, partial, or open | TODO | TODO |/| SYNTHETIC-FINDING-001 | Open | SYNTHETIC-EVIDENCE-001.txt | 2099-01-03 |/' \
  -e 's/^- Asset list$/- Asset list: 192.0.2.10 (synthetic)/' \
  -e 's/^- Evidence index$/- Evidence index: SYNTHETIC-EVIDENCE-001.txt/' \
  -e 's/^- Timeline$/- Timeline: 2099-01-01 synthetic event/' \
  "$REPORT"

echo "[+] loaded vulnerable revision into a disposable Git repository"

for marker in \
  "SYNTHETIC CLIENT - TRAINING ONLY" \
  "192.0.2.10" \
  "test-contact@example.invalid" \
  "SYNTHETIC-EVIDENCE-001.txt"; do
  grep -Fq -- "$marker" "$REPORT"
done
echo "[+] inserted synthetic client, target, contact, and evidence markers"

if grep -Eiq -- "$BOUNDARY_PATTERN" "$REPORT"; then
  echo "[-] inline Git-storage boundary found; target does not match the vulnerable template" >&2
  exit 1
fi
echo "[+] no inline Git-storage boundary found in the populated template"

if git -C "$WORKDIR" check-ignore -q -- "$TEMPLATE_PATH"; then
  echo "[-] populated report is ignored; target does not match the vulnerable Git boundary" >&2
  exit 1
fi
echo "[+] populated report is not ignored"

STAGE_OUTPUT=$(git -C "$WORKDIR" add -n -- "$TEMPLATE_PATH")
grep -Fq -- "add '$TEMPLATE_PATH'" <<< "$STAGE_OUTPUT"
echo "[+] git would stage $TEMPLATE_PATH"

cleanup
trap - EXIT HUP INT TERM
echo "[+] target repository unchanged; temporary workspace removed"
