# Public Drive Folder Exposes the Module 01 Screenshot Collection

| Field | Value |
|---|---|
| Severity | Medium |
| Priority | P2 |
| Weakness | CWE-200: Exposure of Sensitive Information to an Unauthorized Actor |
| Affected revision | `0229ad894c204d3b541825d46d8f95f86f59e3a5` |
| Affected file | `Notes/CPENT_Modules_01_02.md` |
| Root cause | A public source locator points to a Drive folder whose listing is available without authentication |

## Executive Summary

The CPENT study repository publishes a Google Drive folder locator for its
Module 01 source screenshots. The same document describes that source as a
collection of 73 CPENT screenshots. Because the folder's sharing policy allows
signed-out visitors to render its listing, any reader who reaches the Markdown
file can cross from the public repository into the source collection without
requesting access or authenticating.

I reviewed vulnerable revision
`0229ad894c204d3b541825d46d8f95f86f59e3a5` directly. In a signed-out browser,
I observed the title `Principles and obj pT - Google Drive`, a separate sign-in
link, and at least 50 numbered shared PNG entries with file sizes. I did not
open or download any file, and I did not enumerate beyond the initially
rendered listing. No fixed revision was supplied or identified, so the exact
affected version range outside the reviewed revision is unknown.

We rate this issue **Medium (P2)**. Reachability is remote, anonymous, and
low-friction, but the demonstrated impact is limited to confidentiality of a
course-source collection. We did not observe credentials, personal data,
client evidence, code execution, account compromise, or privileged-system
access, and we intentionally did not inspect the image bodies.

## Background

`Notes/CPENT_Modules_01_02.md` is a teacher guide assembled from study source
material. Its opening source assessment tells us both how the guide was built
and what the linked Module 01 collection represents:

```markdown
5  **Purpose:** Convert the supplied CPENT screenshots into an active-learning
   course with practical exercises, recall tests, and reusable engagement
   templates.

9  | Module | Source material | Recovery status | Limitation |
11 | Module 01 — Introduction to Penetration Testing and Methodologies |
   73 screenshots, recovered notes, cram sheet | Complete and well structured |
   No separately labelled official lab guide was found |

14 This guide is a concise teaching synthesis. It does not reproduce the
   courseware page by page.
```

The intended repository invariant is stricter than the vulnerable document.
`SECURITY.md` tells contributors to use synthetic examples and keep sensitive
evidence out of Git:

```markdown
- Replace credentials and tokens with REDACTED.
- Avoid committing packet captures, browser archives, private keys, or raw
  customer exports.
- Use synthetic names and lab-only addresses in examples.
- Store sensitive evidence in an approved encrypted location, not in Git.
```

`CONTRIBUTING.md` goes further for course content:

```markdown
- Do not commit credentials, tokens, personal data, packet captures, or
  proprietary course material.
- Paraphrase concepts in your own words and link to public primary sources.
```

Those controls correctly separate a concise teaching synthesis from raw source
material. The missing invariant is that this separation must cover external
locators as well as files committed directly to Git. A restricted source
folder can remain outside Git, but the public repository must not publish its
locator while the storage ACL permits anonymous listing.

## Vulnerability Details

### The repository publishes the source-folder capability

Near the end of the teacher guide, the source-links section carries the
otherwise opaque folder identifier into public Markdown. The decisive line is
427; the identifier is redacted below to avoid unnecessarily redistributing
the live locator:

```markdown
422 ## Source links
423
424 - [CPENT Notes folder](https://drive.google.com/drive/folders/<folder-id>)
425 - [Module 01 recovered notes](https://drive.google.com/file/d/<file-id>/view)
426 - [Module 01 cram sheet](https://drive.google.com/file/d/<file-id>/view)
427 - [Module 01 screenshot folder](https://drive.google.com/drive/folders/<folder-id>)
```

We can now follow the security-relevant state transition:

1. The public repository describes the source as 73 Module 01 screenshots at
   line 11.
2. Line 427 supplies the complete folder locator and labels its purpose.
3. Google Drive accepts a signed-out visitor and renders the folder grid while
   offering sign-in as a separate, optional action.
4. The visitor can enumerate at least 50 numbered shared PNG entries and their
   sizes from the initial listing.

The folder identifier is not a substitute for authorization. It may be
difficult to guess in isolation, but line 427 eliminates that uncertainty by
publishing the exact value. Likewise, a `Confidential` convention in local
policy would not help here: the effective control is the external folder ACL,
and the observed ACL allows anonymous listing.

### Resulting bad state

The bad state is a mismatch between content minimization and external sharing.
The Git repository contains a synthesis, but it also hands every reader a
capability that reaches the source collection. This defeats the policy goal of
keeping proprietary course material out of the public study repository without
needing the screenshots themselves to be tracked as Git blobs.

The verified disclosure is deliberately narrow. We proved that a signed-out
visitor can see the folder title, numbered PNG filenames, and file sizes. The
repository's own description strongly ties that listing to the Module 01
course screenshots, but we did not open an image, verify page text, test each
file's individual ACL, or confirm that all 73 described screenshots remain in
the folder. These limits matter: the issue is a course-content confidentiality
exposure, not evidence of a compromised Google account or application host.

## Exploitability Analysis

The strongest exploitation route is also the simplest. We start as an
unauthenticated reader of the repository, copy or click the line-427 locator,
and arrive at a readable folder grid. There is no brute force, search-engine
indexing, account registration, access request, token theft, or social
engineering step. The published Markdown supplies both the opaque identifier
and its semantic label.

A repository clone is an equivalent route. Removing the link only from a later
revision does not revoke copies already present in Git history, forks, mirrors,
or local clones. That makes ACL repair the decisive containment step: once the
folder is restricted to named authorized users, historical knowledge of the
identifier should no longer grant anonymous access. Source removal remains
important because it prevents new discovery and documents the intended
boundary, but it cannot serve as the only access control.

We intentionally stopped at the listing. Opening one image could have provided
stronger proof of exact content, and bulk download would have increased the
amount of reproduced material, but neither action was necessary to demonstrate
the broken anonymous folder boundary. Avoiding those branches also keeps the
validation proportionate and prevents the report itself from amplifying the
confidentiality issue.

Several constraints limit impact:

- the observed target is one Drive folder, not a Google account or wider
  storage tenant;
- the full 73-item count was not independently established;
- file bodies and individual-file sharing rules were not tested;
- no credential, token, private key, client target, or personal record was
  observed; and
- ownership intent and licensing authorization were not independently
  verified.

These constraints keep the issue below High. At the same time, the remote
anonymous path, the substantial visible collection, and the repository's own
source description make the confidentiality impact more than a cosmetic link
or metadata observation. Medium severity is therefore the appropriate balance.

## Proof of Concept

The accompanying `poc/` directory contains a local-only source verifier. It
does not contact Google, open a browser, request access, enumerate the folder,
or download files. Instead, it checks a supplied Git checkout, confirms the
Module 01 `73 screenshots` description, and verifies that the line-427 Markdown
contains a Google Drive folder locator. The script redacts the folder identifier
in its output.

From the report directory, run:

```sh
cd poc
./run.sh ../../CPENT-project
```

Representative output on the reviewed vulnerable revision is:

```text
[+] revision: 0229ad894c204d3b541825d46d8f95f86f59e3a5
[+] source claim: Module 01 is backed by 73 screenshots
[+] locator line: Notes/CPENT_Modules_01_02.md:427
[+] locator: Google Drive folder identifier present (redacted)
[+] local source proof complete; no network request was made
```

On a fixed checkout where the external locator has been removed, the script
exits nonzero with `[-] Module 01 screenshot folder locator not found`. It does
not modify the checkout, so no cleanup is required. `poc/README.md` documents
the exact scope, requirements, expected behavior, and limitations.

The local PoC proves the source half of the vulnerability. The anonymous ACL
half requires an authorized signed-out regression check, described below;
the script intentionally does not automate that network action.

## Remediation

The invariant to restore is straightforward: public repository content may
describe synthesized learning material, but it must not expose locators for
restricted or proprietary source collections, and knowledge of a historical
locator must not grant anonymous access.

First, remove line 427's external URL. A minimal repository-safe replacement is:

```markdown
## Source provenance

- Module 01 notes are a teaching synthesis derived from authorized study
  material.
- Raw source screenshots are stored in an approved restricted location and are
  not linked from this repository.
```

Second, change the Drive folder's general access to **Restricted** and grant
access only to named authorized identities. Review inherited sharing on the
folder and its children. Because the identifier already exists in Git history,
consider moving the contents to a new restricted folder or otherwise rotating
the shared resource after revoking the old link. Removing the URL from current
Markdown or rewriting history can reduce discovery, but neither replaces ACL
revocation.

We recommend three regression checks:

1. In a fresh signed-out browser profile, open the old line-427 URL. The test
   passes only if Drive requires authentication or denies access and does not
   render the folder title or any file listing.
2. Confirm that a named authorized account can still reach the restricted
   source material needed for legitimate study work.
3. Add a repository check that rejects private Drive folder/file locators in
   tracked study Markdown unless they are explicitly reviewed public primary
   sources. A focused test should verify that the old Module 01 locator is no
   longer present in the current tree.

Finally, make the external-storage rule explicit beside the existing
`CONTRIBUTING.md` prohibition: raw or proprietary course material must remain
in approved restricted storage, and its private locator must not be published
as a source link.

## Summary

Revision `0229ad894c204d3b541825d46d8f95f86f59e3a5` describes a collection of
73 Module 01 CPENT screenshots and publishes its Google Drive folder locator at
`Notes/CPENT_Modules_01_02.md:427`. We followed that source-to-storage path and
confirmed that a signed-out visitor could render the folder title and at least
50 numbered shared PNG entries without requesting access. We did not open or
download any file.

The vulnerability exists because repository-level content policy is not paired
with an enforced external-storage boundary. Removing the locator prevents new
discovery; restricting or rotating the Drive resource closes access for readers
who already know the historical identifier. Together, those changes restore
the intended separation between a public teaching synthesis and its underlying
course-source collection.
