#!/bin/sh

set -eu

if [ "$#" -ne 1 ]; then
    printf 'usage: %s path/to/CPENT-project\n' "$0" >&2
    exit 2
fi

repo=$1
document=$repo/Notes/CPENT_Modules_01_02.md

if [ ! -d "$repo/.git" ]; then
    printf '[-] supplied path is not a Git checkout: %s\n' "$repo" >&2
    exit 2
fi

if [ ! -f "$document" ]; then
    printf '[-] source document not found: Notes/CPENT_Modules_01_02.md\n' >&2
    exit 2
fi

revision=$(git -C "$repo" rev-parse HEAD 2>/dev/null)
source_line=$(sed -n '11p' "$document")
locator_line=$(sed -n '427p' "$document")

case $source_line in
    *'Module 01'*'73 screenshots'*)
        ;;
    *)
        printf '[-] Module 01 73-screenshot source claim not found\n' >&2
        exit 1
        ;;
esac

locator=$(printf '%s\n' "$locator_line" | sed -n \
    's@.*\[Module 01 screenshot folder\](\(https://drive\.google\.com/drive/folders/[^)]*\)).*@\1@p')

if [ -z "$locator" ]; then
    printf '[-] Module 01 screenshot folder locator not found\n' >&2
    exit 1
fi

folder_id=${locator##*/}
if [ -z "$folder_id" ]; then
    printf '[-] Drive folder identifier is empty\n' >&2
    exit 1
fi

printf '[+] revision: %s\n' "$revision"
printf '[+] source claim: Module 01 is backed by 73 screenshots\n'
printf '[+] locator line: Notes/CPENT_Modules_01_02.md:427\n'
printf '[+] locator: Google Drive folder identifier present (redacted)\n'
printf '[+] local source proof complete; no network request was made\n'
