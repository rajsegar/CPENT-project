# Local Source Proof

This proof of concept verifies the repository-side portion of
`public-drive-module-01-screenshots` without making a network request.

It checks a supplied Git checkout for two facts:

1. `Notes/CPENT_Modules_01_02.md:11` describes Module 01 as backed by 73
   screenshots.
2. `Notes/CPENT_Modules_01_02.md:427` publishes a Google Drive folder locator
   labeled `Module 01 screenshot folder`.

The script does **not** contact Google Drive, open a file, request access,
enumerate remote content, or download anything. It also redacts the folder
identifier from terminal output.

## Requirements

- POSIX-compatible `sh`
- `git`
- `sed`

## Run

From the disclosure report directory:

```sh
cd poc
./run.sh ../../CPENT-project
```

For the reviewed vulnerable revision, compare the output with
`expected-output.txt`.

## Expected vulnerable behavior

The script exits zero after confirming both the source description and the
published locator. It prints the checkout revision but not the folder
identifier.

## Expected fixed behavior

Once the public locator has been removed, the script exits nonzero with:

```text
[-] Module 01 screenshot folder locator not found
```

The script proves only the committed source path. The storage-side regression
test must be performed manually within authorization: a fresh signed-out
browser should receive an access-denied or sign-in-only response and must not
render the folder title or file listing.

## Safety and cleanup

The script performs local reads only and does not change the checkout. No
cleanup is required.
