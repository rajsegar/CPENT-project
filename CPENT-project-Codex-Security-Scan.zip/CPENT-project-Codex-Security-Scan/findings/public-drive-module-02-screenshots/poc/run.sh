#!/bin/sh

set -eu

if [ "$#" -ne 1 ]; then
    printf 'usage: %s path/to/CPENT-project\n' "$0" >&2
    exit 2
fi

repo=${1%/}
document=$repo/Notes/CPENT_Modules_01_02.md

if [ ! -d "$repo/.git" ]; then
    printf '[-] supplied path is not a Git checkout: %s\n' "$repo" >&2
    exit 2
fi

if [ ! -f "$document" ]; then
    printf '[-] source document not found: Notes/CPENT_Modules_01_02.md\n' >&2
    exit 2
fi

revision=$(git -C "$repo" rev-parse HEAD 2>/dev/null)
source_line=$(sed -n '12p' "$document")
synthesis_line=$(sed -n '14p' "$document")
locator_line=$(sed -n '428p' "$document")

case $source_line in
    *'Module 02'*'105 screenshots'*'pages 79–190'*)
        ;;
    *)
        printf '[-] Module 02 105-screenshot source claim not found\n' >&2
        exit 1
        ;;
esac

case $synthesis_line in
    *'does not reproduce the courseware page by page'*)
        ;;
    *)
        printf '[-] page-by-page synthesis boundary not found\n' >&2
        exit 1
        ;;
esac

locator_present=$(printf '%s\n' "$locator_line" | sed -n \
    's@.*\[Module 02 screenshot folder\](https://drive\.google\.com/drive/folders/[A-Za-z0-9_-][A-Za-z0-9_-]*)[[:space:]]*$@present@p')

if [ "$locator_present" != 'present' ]; then
    printf '[-] Module 02 screenshot folder locator not found\n' >&2
    exit 1
fi

printf '[+] revision: %s\n' "$revision"
printf '[+] source claim: Module 02 is backed by 105 screenshots covering pages 79-190\n'
printf '[+] synthesis boundary: the guide does not reproduce courseware page by page\n'
printf '[+] locator line: Notes/CPENT_Modules_01_02.md:428\n'
printf '[+] locator: Google Drive folder identifier present (redacted)\n'
printf '[+] local source proof complete; no network request was made\n'
