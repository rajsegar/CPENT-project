# Local Source Proof

This proof of concept verifies the repository-side portion of
`public-drive-module-02-screenshots` without making a network request or
distributing the live Google Drive folder identifier.

It checks a supplied Git checkout for three facts:

1. `Notes/CPENT_Modules_01_02.md:12` describes Module 02 as backed by 105
   screenshots covering pages 79–190.
2. `Notes/CPENT_Modules_01_02.md:14` says the guide does not reproduce the
   courseware page by page.
3. `Notes/CPENT_Modules_01_02.md:428` publishes a syntactically valid Google
   Drive folder locator labeled `Module 02 screenshot folder`.

The script reduces the locator match to a boolean result and never prints the
source line, URL, or folder identifier. It does **not** contact Google Drive,
open a file, request access, enumerate remote content, or download anything.

## Requirements

- POSIX-compatible `sh`
- `git`
- `sed`

## Run

From the disclosure report directory:

```sh
cd poc
sh -n run.sh
./run.sh ../../CPENT-project
```

For the reviewed vulnerable revision, compare the output with
`expected-output.txt`.

## Expected vulnerable behavior

The script exits zero after confirming the source classification, synthesis
boundary, and published locator. It prints the checkout revision but not the
folder identifier.

## Expected fixed behavior

After the public locator is removed, the script exits nonzero with:

```text
[-] Module 02 screenshot folder locator not found
```

## Separate authorized ACL regression

The script proves only the committed source path. Storage-side verification is
a separate manual step that requires explicit authorization. An approved
reviewer should retrieve the previously disclosed locator through a secure
channel, open it in a fresh signed-out browser, and confirm that an
access-denied, request-access, or sign-in-only gate replaces the folder grid.

Do not open or preview a file. Do not activate `Download all`. Stop as soon as
the access gate is established. This PoC intentionally contains no live URL for
that manual step.

## Safety and cleanup

The script performs local reads only and does not change the checkout. No
cleanup is required.
