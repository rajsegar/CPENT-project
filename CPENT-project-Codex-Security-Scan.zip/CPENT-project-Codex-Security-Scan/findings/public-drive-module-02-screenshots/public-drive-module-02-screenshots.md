# Public Google Drive Folder Exposes 105 Module 02 Course Screenshots

## Executive Summary

Revision `0229ad894c204d3b541825d46d8f95f86f59e3a5` of CPENT-project publishes a
stable Google Drive folder locator in `Notes/CPENT_Modules_01_02.md:428`. The
same document identifies the folder's source material as 105 screenshots
covering CPENT Module 02 course pages 79–190. Authorized validation captured a
signed-out browser rendering the shared PNG listing and file sizes without an
access request; the same view exposed a `Download all` control.

The failure crosses the repository-to-external-storage trust boundary. A
public document supplies a capability-like locator for material that the
repository classifies as page-level course screenshots, while the external
access-control list (ACL) accepts an anonymous visitor who possesses that
locator. The demonstrated impact is confidentiality loss for one substantial,
contiguous collection of proprietary course material. The evidence does not
show credentials, personal data, access to unrelated folders, compromise of a
Google account, or code execution.

I reviewed the vulnerable revision directly and ran the included offline source
checker against that revision. I did not contact Google Drive or repeat the
signed-out browser test while preparing this report. The storage-side facts
above come from the authorized validation record, which also states that no
image was opened and no download was initiated. No fixed revision was available
for comparison, and the introduction point or first affected release was not
established.

The finding is **High severity (P1)**. Exploitation is remote, public,
unauthenticated, and low-friction, and the exposed interface offers bulk access
to a collection described by the repository as 105 contiguous course-page
screenshots. It is not Critical because the verified primitive is limited to
data and intellectual-property exposure in one folder, without account or
system compromise.

The live folder identifier is intentionally redacted throughout this report and
its proof of concept (PoC). Authorized maintainers can retrieve it from the
affected revision when performing remediation, without redistributing it in the
disclosure bundle.

## Background

CPENT-project is a study knowledge base. Its teacher guide explains why the
external screenshots exist and distinguishes them from the synthesized material
kept in the repository. At `Notes/CPENT_Modules_01_02.md:5,9-14`, we find:

```markdown
**Purpose:** Convert the supplied CPENT screenshots into an active-learning course with practical exercises, recall tests, and reusable engagement templates.

| Module | Source material | Recovery status | Limitation |
|---|---|---|---|
| Module 02 — Penetration Testing Scoping and Engagement | 105 screenshots covering course pages 79–190 | OCR completed and key pages visually validated | No separate text notes or separately labelled official lab guide was found |

This guide is a concise teaching synthesis. It does not reproduce the courseware page by page.
```

This establishes the intended data boundary: the public guide is a concise
synthesis, while a page-level screenshot collection is stored elsewhere.
`CONTRIBUTING.md:20-23` reinforces that boundary by prohibiting proprietary
course material and directing contributors to paraphrase concepts and link to
public primary sources. `SECURITY.md:17-23` likewise requires sensitive study
evidence to be redacted and kept in approved storage.

External storage can preserve that boundary only if its ACL rejects anonymous
access. Keeping the bytes outside Git is not sufficient when a public document
publishes the resource's stable locator and the external service treats
possession of that locator as authorization. At least one of these invariants
must therefore hold:

1. the public repository does not disclose a restricted collection's locator;
2. the external folder rejects unauthenticated access even when its locator is
   known.

The affected revision satisfies neither invariant.

## Vulnerability Details

The source-to-storage path begins in the guide's `Source links` section at
`Notes/CPENT_Modules_01_02.md:422-428`. The affected line is reproduced with the
sensitive value removed:

```markdown
- [Module 02 screenshot folder](https://drive.google.com/drive/folders/<REDACTED_FOLDER_ID>)
```

The exact affected location is `Notes/CPENT_Modules_01_02.md:428`. We can carry
the classification from line 12 into this link: line 12 describes 105 Module 02
screenshots spanning course pages 79–190, and line 428 labels its published
locator as the Module 02 screenshot folder. A repository reader consequently
does not need to guess or enumerate the otherwise opaque identifier.

The second half of the failure is the external ACL. In the captured authorized
test, the exact line-428 locator was opened in a signed-out browser. The page
rendered a Google Drive folder grid containing shared PNG entries and their
sizes. A separate sign-in affordance remained visible, so the listing was not
the result of an authenticated Google session. The signed-out toolbar also
offered `Download all` rather than an access-denied or request-access gate.

That evidence gives us the following state transition:

| Stage | Repository or storage state | Security consequence |
| --- | --- | --- |
| Before locator publication | The folder identifier may be difficult to discover, although ACL enforcement is still required. | No repository-mediated path has been established. |
| After line 428 | Any repository reader receives the exact folder identifier. | Discovery becomes trivial and remains durable in Git history. |
| Signed-out navigation | Drive renders the folder grid without an access request. | Anonymous enumeration of shared PNG objects is verified. |
| Bulk control exposed | Drive offers `Download all` to the signed-out visitor. | A collection-wide retrieval path is presented, although validation intentionally did not execute it. |

Policy documents are useful preventive controls, but they are not enforcement
points. `CONTRIBUTING.md` cannot remove line 428 or change the folder ACL, and
`SECURITY.md` cannot make an anonymously shared collection private. The
vulnerable state is the combination of locator publication and permissive
external sharing.

## Exploitability Analysis

The strongest exploitation route is deliberately simple. We first read the
public teacher guide, which tells us the type and range of the source material.
We then follow the stable folder link while signed out. Drive renders the shared
PNG listing, allowing anonymous enumeration, and exposes a bulk-download
control. The path needs no search-engine indexing, folder-ID guessing, session
confusion, race condition, social engineering, or specialist tooling.

Git history makes the route durable. Once a locator has been published, deleting
the current Markdown line does not make that identifier secret again. A reader
who already learned it can retain or forward it independently of the repository.
This does not broaden the ACL primitive, but it means repository cleanup alone
cannot restore confidentiality; the storage ACL must carry the security
guarantee.

We should also keep the limits of the evidence explicit:

- The authorized test did not open an image or activate `Download all`, so it
  did not confirm every file body byte-for-byte.
- The collection classification comes from the repository's own source table,
  supported by the matching folder context and the rendered PNG listing.
- Validation covered one folder only. There is no evidence of access to sibling
  folders, the owner's wider Drive, or account-level data.
- No credential, token, private key, personal record, or production-system
  access was observed.
- The ACL and folder contents can change after validation. Remediation must be
  rechecked at the time it is applied.

Those constraints prevent us from overstating this as account compromise, but
they do not reduce it to metadata leakage. Anonymous listing exposed shared PNG
objects and sizes, the service presented `Download all`, and the repository
described the linked set as 105 contiguous course-page screenshots. That
supports High severity for proprietary-data exposure while preserving the
single-folder scope.

## Proof of Concept

The PoC is intentionally offline. `poc/run.sh` inspects a supplied Git checkout
and confirms three repository-side facts without embedding or printing the live
identifier:

1. line 12 classifies Module 02 as backed by 105 screenshots spanning pages
   79–190;
2. line 14 describes the guide as a synthesis rather than page-by-page
   courseware; and
3. line 428 publishes a syntactically valid Google Drive folder locator under
   the `Module 02 screenshot folder` label.

The checker reduces any matching locator to a boolean `present` result before
printing output. It performs local file reads and Git metadata inspection only;
it does not resolve the URL, contact Google Drive, open a file, enumerate remote
content, or download anything.

From the disclosure report directory, run:

```sh
cd poc
sh -n run.sh
./run.sh ../../CPENT-project
```

Against the reviewed vulnerable revision, representative output is:

```text
[+] revision: 0229ad894c204d3b541825d46d8f95f86f59e3a5
[+] source claim: Module 02 is backed by 105 screenshots covering pages 79-190
[+] synthesis boundary: the guide does not reproduce courseware page by page
[+] locator line: Notes/CPENT_Modules_01_02.md:428
[+] locator: Google Drive folder identifier present (redacted)
[+] local source proof complete; no network request was made
```

Once the public locator is removed, the expected result is a nonzero exit with:

```text
[-] Module 02 screenshot folder locator not found
```

The PoC proves only the committed source path. Storage-side ACL verification is
a **separate, authorized manual regression step**: an approved reviewer should
use the previously disclosed locator through a secure channel in a clean
signed-out browser and confirm that an access-denied, request-access, or
sign-in-only gate replaces the folder grid. The reviewer must not open a file or
activate `Download all`. The disclosure bundle intentionally provides no live
URL for that step.

The script changes no local or remote state, so it needs no cleanup.

## Remediation

The invariant to restore is straightforward: possession of a locator once
published in the repository must not grant an anonymous user access to
non-public source material.

The minimal source patch removes the capability-like link while retaining a
non-sensitive explanation:

```diff
-- [Module 02 screenshot folder](https://drive.google.com/drive/folders/<REDACTED_FOLDER_ID>)
+- Module 02 source screenshots are stored in restricted, approved storage and are not linked from the public repository.
```

That repository change must be paired with an ACL change in Google Drive:

1. Set the folder's general access to **Restricted** and remove
   `Anyone with the link` access.
2. Review inherited and per-item sharing so children do not remain anonymously
   accessible through their own links.
3. Limit access to named, authorized identities, or delete the external
   collection if retaining it is not authorized.
4. Treat the previously published identifier as permanently disclosed. ACL
   enforcement, not URL secrecy, must carry the security guarantee.

For structural hardening, repository review or continuous integration can flag
new `drive.google.com/drive/folders/` strings unless an explicit, documented
public-resource exception exists. That source check should supplement, not
replace, review of external sharing permissions.

Regression testing should exercise both sides of the boundary:

1. Run `poc/run.sh` and confirm that current source no longer contains the
   Module 02 folder locator.
2. Through an approved secure channel, retrieve the previously published
   locator and open it in a clean signed-out browser.
3. Confirm that Drive shows a sign-in, request-access, or access-denied gate and
   does not render the folder grid, filenames, sizes, or `Download all`.
4. Confirm separately that named authorized reviewers retain only the intended
   access.

The ACL check must remain manual and authorization-bound; it should not be
encoded in a distributable script or automated against the live service.

## Summary

Revision `0229ad894c204d3b541825d46d8f95f86f59e3a5` combines two failed controls:
`Notes/CPENT_Modules_01_02.md:428` publishes the Module 02 Drive folder locator,
and the folder ACL allows a signed-out visitor to enumerate shared PNG objects
and reach a `Download all` control. The same source identifies the collection as
105 screenshots covering CPENT pages 79–190, making the impact materially
broader than an isolated filename or broken-link issue.

We can prove the repository-side disclosure safely with the included offline
checker, while the captured authorized browser evidence establishes the
storage-side condition. Removing the public link and restricting the folder ACL
closes the immediate path. Future research should inspect current and historical
external-storage links for the same publication-plus-permissive-ACL pattern,
using redacted local discovery first and separately authorized manual ACL tests.
