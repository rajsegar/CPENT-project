# Finding Template Can Carry Unredacted Evidence into Git History

| Field | Value |
|---|---|
| Severity | Low |
| Priority | P3 |
| Weakness | CWE-200: Exposure of Sensitive Information to an Unauthorized Actor |
| Affected revision | `0229ad894c204d3b541825d46d8f95f86f59e3a5` |
| Entrypoint | `README.md:24-26` |
| Root control / sink | `Reports/Finding-Report-Template.md:29-31` |

## Executive Summary

The repository's beginner workflow tells learners to collect lab evidence and
use `Reports/Finding-Report-Template.md` for a reportable issue. At the exact
point where that template asks for screenshots, request/response snippets,
commands, or logs, it does not require redaction, minimal sanitized excerpts,
or private storage for raw originals. Those evidence forms commonly contain
authorization headers, cookies, personal data, internal addresses, client
identifiers, or private targets. A learner can therefore paste sensitive
material into an ordinary Markdown report and commit it to persistent Git
history.

I statically reviewed revision
`0229ad894c204d3b541825d46d8f95f86f59e3a5` and exercised the workflow only with
clearly synthetic evidence in a disposable temporary repository. I did not use
a live secret, access a real target, or modify the source checkout. No fixed
revision was supplied or identified, so the affected range outside the reviewed
revision is unknown.

This is an unsafe-default workflow, not a current secret disclosure. The
repository already has strong global redaction policy, and exploitation
requires a learner to select sensitive evidence, paste it, and commit the
completed report. We therefore rate it **Low (P3)**: the confidentiality impact
could be meaningful if the path completes, but the likelihood is moderated by
those user actions and existing countercontrols.

## Background

The project is a Markdown study knowledge base, so its security boundaries are
content workflows rather than runtime handlers. The relevant flow begins in the
root `README.md`, which guides a beginner from an authorized lab into evidence
collection and report writing:

```markdown
21 5. Run the suggested exercise in an authorized lab.
22 6. Record evidence and write a short finding.
23
24 Use [Templates/Lab-Template.md](Templates/Lab-Template.md) before each lab and
25 [Reports/Finding-Report-Template.md](Reports/Finding-Report-Template.md) when a
26 lab produces a reportable issue.
```

This direct link matters. We do not need to assume that a learner discovers an
obscure helper file or invents a reporting convention; the primary workflow
selects the exact template for them.

The intended evidence-handling invariant is visible elsewhere. `SECURITY.md`
requires `REDACTED` substitutions and approved private storage:

```markdown
- Replace credentials and tokens with REDACTED.
- Avoid committing packet captures, browser archives, private keys, or raw
  customer exports.
- Use synthetic names and lab-only addresses in examples.
- Store sensitive evidence in an approved encrypted location, not in Git.
```

The controls are reinforced by other files:

- `AGENTS.md:17-20,72-78` prohibits real credentials, customer data, private
  targets, and unredacted screenshots and requires report redaction.
- `CONTRIBUTING.md:21-22,34-41` bans credentials, tokens, personal data, packet
  captures, and proprietary material and includes a sensitive-data review item.
- `Reports/Evidence-Log-Template.md:7-14` tells users to redact report copies and
  keep sensitive originals in an approved evidence location.
- `Labs/README.md:12-23` limits screenshots, requires minimal evidence, and says
  secrets must be redacted before commit.

These are valuable defense-in-depth controls. The vulnerability is that none is
carried into or linked from the evidence field that the beginner workflow
actually reaches. Markdown does not inherit safety rules from a sibling file,
and the workflow does not require the learner to visit those controls before
completing the report.

## Vulnerability Details

### The evidence field accepts high-risk content without a local guard

The vulnerable template is only 39 lines long. The relevant transition is
unambiguous:

```markdown
23 ## Steps to reproduce
24
25 1. Step one
26 2. Step two
27 3. Step three
28
29 ## Evidence
30
31 Add screenshots, request/response snippets, commands, or logs.
32
33 ## Remediation
```

We first arrive with evidence collected from a lab. If we carry a raw HTTP
exchange or terminal transcript into line 31, common sensitive fields move with
it. A synthetic example illustrates the shape without using a real secret:

```text
Authorization: Bearer SYNTHETIC-DEMO-TOKEN-NOT-A-SECRET
Cookie: session=SYNTHETIC-DEMO-COOKIE-NOT-A-SECRET
GET /synthetic-finding HTTP/1.1
Host: example-lab.local
[synthetic-log] user=TEST_USER target=192.0.2.10
```

Nothing in the template tells us to replace the header or cookie with
`REDACTED`, remove personal or client fields, capture only the minimum excerpt,
or keep the raw request and screenshot outside Git. The completed report remains
plain Markdown, so Git stages it without recognizing that its Evidence section
has crossed a confidentiality boundary.

### Source, control, and sink

The full path is:

1. `README.md:24-26` routes a beginner with freshly collected evidence to the
   finding template.
2. Lab output supplies the data. It may be operator controlled, target
   controlled, or partly attacker influenced through response headers and logs.
3. `Reports/Finding-Report-Template.md:29-31` requests raw evidence classes but
   omits the point-of-entry redaction and private-storage rule.
4. The learner saves and commits the Markdown report.
5. Repository readers, forks, clones, and later Git-history consumers can
   recover any sensitive value that was included.

The current template contains only a synthetic `.local` asset example and no
live sensitive value. This is important counterevidence: we are proving a
reachable unsafe state, not reporting that a credential is already exposed.
The eventual data crossing depends on a learner choosing sensitive content and
committing it.

### Why the global rules do not close this instance

`SECURITY.md` is clear enough that a careful contributor who reads and applies
it should avoid the problem. The evidence-log and lab guides also contain the
exact kind of local language the finding template needs. But the README links
directly to the finding template, not to those handling sections, and the
template neither restates nor references them.

`AGENTS.md` is primarily instruction for AI-assisted repository work, while
`CONTRIBUTING.md` applies when a user consciously enters the contribution
process. Neither is an enforcement mechanism for a beginner manually filling
the linked report. These controls reduce likelihood; they do not make the
unsafe source-to-sink path unreachable.

## Exploitability Analysis

This issue is not a traditional remote code-execution or authorization-bypass
primitive. The public reader cannot force a learner to publish evidence. The
failure mode is a predictable documentation workflow: the repository asks a
beginner to collect high-risk artifacts, directs them to a report template, and
omits the safety rule exactly where those artifacts are inserted.

The strongest route uses request/response text because it is easy to paste into
Markdown and routinely includes headers, cookies, identifiers, and target
details. Command transcripts and logs are similarly useful because they can
carry environment values, usernames, filesystem paths, or internal addresses.
Screenshots create another path: they may preserve secrets that would have been
obvious in editable text, while visual redaction is easier to overlook.

A malicious lab target could influence response or log content, but that does
not turn this into automatic exfiltration. We still need the learner to select
the artifact, paste it, and commit it. Likewise, a completed report may be
stored outside the repository, a reviewer may apply the global policy, or a
secret scanner may catch a conventional token. These are realistic dead ends
for the disclosure chain and are why likelihood is Medium rather than High.

If the path completes, impact varies widely. A benign banner or synthetic lab
address has little consequence. A reusable session cookie, client identifier,
private target, or personal record can create meaningful confidentiality harm,
and Git history makes revocation harder. Because no live value or privilege
level is known, we calibrate impact to Medium rather than selecting a
worst-case high-privilege credential story. Medium impact combined with Medium
likelihood yields a final Low severity under the applied policy matrix.

## Proof of Concept

The accompanying PoC reproduces the unsafe workflow without touching the
source checkout or using a live secret. It:

1. copies `Reports/Finding-Report-Template.md` into a temporary directory;
2. inserts clearly marked synthetic Authorization, cookie, request, and log
   lines below the Evidence instruction;
3. initializes a disposable Git repository and stages the completed Markdown;
4. verifies that the template contains no point-of-entry redaction or
   private-storage warning; and
5. confirms the source template hash did not change before deleting the
   temporary directory.

Run it from the report directory:

```sh
cd poc
./run.sh ../../CPENT-project
```

Representative output on the affected revision is:

```text
[+] copied finding template into a disposable directory
[+] inserted 5 clearly synthetic evidence markers
[+] completed-finding.md is staged as a normal Git file
[+] point-of-entry redaction/private-storage warning: absent
[+] source checkout modified: no
[+] cleanup: disposable directory removed
```

On a fixed template with an adjacent redaction or approved-private-storage
instruction, the PoC exits nonzero and reports that the warning is present. It
does not create a Git commit, contact a network service, or retain its temporary
files. `poc/README.md` documents the exact markers, requirements, limitations,
and cleanup behavior.

## Remediation

The invariant should be explicit at the evidence sink: a repository-safe report
contains only the minimum sanitized proof; credentials, tokens, cookies,
personal/client identifiers, and private targets are replaced with
`REDACTED`; raw originals remain in approved private evidence storage.

A minimal template fix is:

```markdown
## Evidence

Add only the minimum sanitized screenshot, request/response excerpt, command,
or log needed to prove the result.

- Replace credentials, tokens, cookies, personal/client identifiers, and
  private targets with `REDACTED` before saving or committing this report.
- Keep raw screenshots, full requests/responses, and logs in the approved
  private evidence location; do not commit raw originals to Git.
- Record redaction or transformation steps in the
  [evidence log](Evidence-Log-Template.md).
```

This restores the rule at the point where the learner makes the risky choice.
The global policies should remain; the local instruction makes them reachable
and concrete rather than duplicating them for its own sake.

We recommend regression checks at three layers:

1. **Template lint:** fail if the Evidence section asks for screenshots,
   requests, responses, commands, or logs without nearby `REDACTED` and private
   evidence-storage language.
2. **Synthetic workflow test:** copy the template, insert known markers such as
   `SYNTHETIC-DEMO-TOKEN-NOT-A-SECRET`, and verify the template warning is
   present before Git staging is treated as safe.
3. **Repository scanning:** run secret detection and a content review before
   merge, recognizing that scanners are defense in depth and may not identify
   private targets, screenshots, or client context.

The root README can also link the evidence-log handling section beside the
finding-template link. That makes the safe path visible before a learner begins
the report, while the template-local text remains the decisive control.

## Summary

Revision `0229ad894c204d3b541825d46d8f95f86f59e3a5` routes beginners from lab
evidence collection to `Reports/Finding-Report-Template.md`, whose line 31 asks
for screenshots, request/response snippets, commands, or logs without an
adjacent redaction or private-storage requirement. We reproduced the resulting
state with synthetic markers in a disposable repository: the completed report
remains an ordinary stageable Markdown file, while the source checkout remains
unchanged.

No current secret is exposed, and strong repository-wide policy plus required
learner actions limit likelihood. The issue remains worth fixing at Low/P3
because a small point-of-entry template change can prevent sensitive evidence
from becoming durable public Git history. Variant review should focus on other
report, lab, and note templates that solicit screenshots, logs, requests,
responses, asset lists, or contact details without carrying the same local
handling invariant.
