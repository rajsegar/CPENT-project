# Synthetic Finding-Template Workflow PoC

This proof of concept reproduces the template workflow with synthetic evidence
only. It never edits the supplied checkout and never uses a live credential,
token, cookie, account, target, or client value.

The script:

1. copies `Reports/Finding-Report-Template.md` to a temporary directory;
2. inserts these clearly synthetic markers below its Evidence instruction:
   - `SYNTHETIC-DEMO-TOKEN-NOT-A-SECRET`
   - `SYNTHETIC-DEMO-COOKIE-NOT-A-SECRET`
   - `GET /synthetic-finding HTTP/1.1`
   - `Host: example-lab.local`
   - `[synthetic-log] user=TEST_USER target=192.0.2.10`
3. stages the completed Markdown in a disposable Git repository;
4. checks whether the template contains a point-of-entry redaction or approved
   private-storage instruction; and
5. removes the temporary directory automatically.

`192.0.2.10` is in the TEST-NET-1 documentation range. None of the markers is a
usable secret or real target.

## Requirements

- POSIX-compatible `sh`
- `git`
- `awk`, `grep`, `cp`, and `mktemp`

## Run

From the disclosure report directory:

```sh
cd poc
./run.sh ../../CPENT-project
```

Compare the affected-template output with `expected-output.txt`.

## Expected affected behavior

The script exits zero after showing that the completed report is a normal
staged Markdown file and the point-of-entry warning is absent.

## Expected fixed behavior

After adding adjacent redaction/private-storage language to the template, the
script exits nonzero with:

```text
[-] point-of-entry redaction/private-storage warning is present
```

That nonzero result means this specific missing-control condition is no longer
reproduced. A separate regression lint should assert the exact required wording
rather than relying only on this demonstration script.

## Safety, cleanup, and limitations

The PoC performs local filesystem and local Git-index operations only. It does
not create a commit or make a network request. A shell trap removes the
temporary directory on success, failure, or interruption. The source file's
Git object hash is checked before and after the demonstration to confirm the
checkout was not modified.

This PoC demonstrates a reachable unsafe workflow, not an active credential
leak. The supplied repository contains no live secret in this template.
