#!/bin/sh

set -eu

if [ "$#" -ne 1 ]; then
    printf 'usage: %s path/to/CPENT-project\n' "$0" >&2
    exit 2
fi

repo=$1
source_template=$repo/Reports/Finding-Report-Template.md

if [ ! -d "$repo/.git" ]; then
    printf '[-] supplied path is not a Git checkout: %s\n' "$repo" >&2
    exit 2
fi

if [ ! -f "$source_template" ]; then
    printf '[-] source template not found: Reports/Finding-Report-Template.md\n' >&2
    exit 2
fi

source_hash_before=$(git -C "$repo" hash-object \
    Reports/Finding-Report-Template.md)

workdir=$(mktemp -d "${TMPDIR:-/tmp}/finding-template-poc.XXXXXX")
cleanup() {
    rm -rf "$workdir"
}
trap cleanup EXIT HUP INT TERM

cp "$source_template" "$workdir/completed-finding.md"

awk '
    { print }
    $0 == "Add screenshots, request/response snippets, commands, or logs." {
        print ""
        print "```text"
        print "Authorization: Bearer SYNTHETIC-DEMO-TOKEN-NOT-A-SECRET"
        print "Cookie: session=SYNTHETIC-DEMO-COOKIE-NOT-A-SECRET"
        print "GET /synthetic-finding HTTP/1.1"
        print "Host: example-lab.local"
        print "[synthetic-log] user=TEST_USER target=192.0.2.10"
        print "```"
    }
' "$workdir/completed-finding.md" > "$workdir/completed-finding.tmp"
mv "$workdir/completed-finding.tmp" "$workdir/completed-finding.md"

marker_count=$(grep -Ec \
    'SYNTHETIC-DEMO-TOKEN|SYNTHETIC-DEMO-COOKIE|GET /synthetic-finding|Host: example-lab.local|\[synthetic-log\]' \
    "$workdir/completed-finding.md")

if [ "$marker_count" -ne 5 ]; then
    printf '[-] failed to insert all synthetic evidence markers\n' >&2
    exit 1
fi

git -C "$workdir" init -q
git -C "$workdir" add completed-finding.md
git -C "$workdir" ls-files --error-unmatch completed-finding.md >/dev/null

if grep -Eiq \
    'redact(ed|ion)?|approved (private )?evidence|private (storage|location)|sensitive (values|evidence)' \
    "$source_template"; then
    printf '[-] point-of-entry redaction/private-storage warning is present\n' >&2
    exit 1
fi

source_hash_after=$(git -C "$repo" hash-object \
    Reports/Finding-Report-Template.md)

if [ "$source_hash_before" != "$source_hash_after" ]; then
    printf '[-] source template changed during PoC\n' >&2
    exit 1
fi

printf '[+] copied finding template into a disposable directory\n'
printf '[+] inserted 5 clearly synthetic evidence markers\n'
printf '[+] completed-finding.md is staged as a normal Git file\n'
printf '[+] point-of-entry redaction/private-storage warning: absent\n'
printf '[+] source checkout modified: no\n'

cleanup
trap - EXIT HUP INT TERM
printf '[+] cleanup: disposable directory removed\n'
